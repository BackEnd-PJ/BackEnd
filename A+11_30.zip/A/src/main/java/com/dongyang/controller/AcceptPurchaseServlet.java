package com.dongyang.controller;

import java.io.IOException;
import com.dongyang.dao.NotificationDAO;
import com.dongyang.dao.ProductDAO;
import com.dongyang.dto.MemberDTO;
import com.dongyang.dto.ProductDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/acceptPurchase.do")
public class AcceptPurchaseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        HttpSession session = request.getSession();
        MemberDTO seller = (MemberDTO) session.getAttribute("memberId");
        
        // 1. 로그인 확인
        if (seller == null) {
            response.getWriter().write("{\"status\": \"not_login\"}");
            return;
        }

        // 2. 파라미터 수신
        String buyerId = request.getParameter("buyerId"); 
        int productId = Integer.parseInt(request.getParameter("productId"));
        
        // 3. 상품 정보 가져오기
        ProductDAO pDao = new ProductDAO();
        ProductDTO product = pDao.getProductById(productId);
        String productName = (product != null) ? product.getName() : "상품";

        // 4. ⭐️ [수정] 구매자에게 보낼 메시지에 판매자 이메일 포함
        String message = "'" + seller.getName() + "'님이 [" + productName + "] 거래 요청을 수락했습니다!";
        
        NotificationDAO nDao = new NotificationDAO();
        boolean success = nDao.sendNotification(buyerId, seller.getMemberid(), productId, message);
        
        // 5. 결과 응답
        if (success) {
            response.getWriter().write("{\"status\": \"success\"}");
        } else {
            response.getWriter().write("{\"status\": \"fail\"}");
        }
    }
}