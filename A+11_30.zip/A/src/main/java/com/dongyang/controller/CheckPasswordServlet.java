package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import com.dongyang.dto.MemberDTO;

// 🌟 이 주소("/checkPassword.do")가 있어야 모달창이 작동합니다!
@WebServlet("/checkPassword.do")
public class CheckPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 한글 및 JSON 응답 설정
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        HttpSession session = request.getSession();
        MemberDTO user = (MemberDTO) session.getAttribute("memberId");
        
        // 클라이언트(모달창)에서 보낸 비밀번호 받기
        String inputPwd = request.getParameter("password");
        boolean isValid = false;

        // 세션에 저장된 진짜 비밀번호와 비교
        if (user != null && user.getPassword() != null && user.getPassword().equals(inputPwd)) {
            isValid = true;
        }

        // 결과(true/false)를 JSON 형태로 보냄
        PrintWriter out = response.getWriter();
        out.print("{\"valid\": " + isValid + "}");
        out.flush();
    }
}