package com.dongyang.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import com.dongyang.util.JdbcConnectUtil;
import com.dongyang.dto.ReviewDTO; // DTO는 아래 참고

public class ReviewDAO {
    public boolean insertReview(String reviewerId, String sellerId, int productId, double rating, String content) {
        Connection con = null;
        PreparedStatement pstmt = null;
        boolean result = false;
        
        try {
            con = JdbcConnectUtil.getConnection();
            
            // 1. 후기 저장
            String sqlInsert = "INSERT INTO reviewTbl(reviewer_id, seller_id, product_id, rating, content) VALUES(?, ?, ?, ?, ?)";
            pstmt = con.prepareStatement(sqlInsert);
            pstmt.setString(1, reviewerId);
            pstmt.setString(2, sellerId);
            pstmt.setInt(3, productId);
            pstmt.setDouble(4, rating);
            pstmt.setString(5, content);
            pstmt.executeUpdate();
            
            // 2. 판매자 평점(GPA) 재계산 업데이트
            String sqlUpdate = "UPDATE memberTbl SET gpa = (SELECT AVG(rating) FROM reviewTbl WHERE seller_id = ?) WHERE memberid = ?";
            pstmt = con.prepareStatement(sqlUpdate);
            pstmt.setString(1, sellerId);
            pstmt.setString(2, sellerId);
            pstmt.executeUpdate();
            
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
        return result;
    }
    
 // ⭐️ [신규] 특정 판매자가 받은 후기 목록 조회 (최신순)
    public List<ReviewDTO> getReviewsBySellerId(String sellerId) {
        List<ReviewDTO> list = new ArrayList<>();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        // 후기 테이블 + 회원 테이블(작성자명) + 상품 테이블(상품명) 조인
        String sql = "SELECT r.*, m.name AS reviewer_name, p.name AS product_name " +
                     "FROM reviewTbl r " +
                     "JOIN memberTbl m ON r.reviewer_id = m.memberid " +
                     "JOIN productstbl p ON r.product_id = p.id " +
                     "WHERE r.seller_id = ? " +
                     "ORDER BY r.created_at DESC";
                     
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, sellerId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                ReviewDTO dto = new ReviewDTO();
                dto.setId(rs.getInt("id"));
                dto.setReviewerId(rs.getString("reviewer_id"));
                dto.setSellerId(rs.getString("seller_id"));
                dto.setProductId(rs.getInt("product_id"));
                dto.setRating(rs.getDouble("rating"));
                dto.setContent(rs.getString("content"));
                dto.setCreatedAt(rs.getTimestamp("created_at"));
                
                // 조인된 데이터 (화면 표시용)
                dto.setReviewerName(rs.getString("reviewer_name"));
                dto.setProductName(rs.getString("product_name"));
                
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return list;
    }
    
}