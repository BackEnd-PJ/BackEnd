package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/updateProfile.do")
public class UpdateProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        HttpSession session = request.getSession();
        MemberDTO loginUser = (MemberDTO) session.getAttribute("memberId");

        if (loginUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 1. 입력값 받기 (닉네임, 이메일)
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        // 2. DTO 생성 (수정할 정보 담기)
        MemberDTO updateDto = new MemberDTO();
        updateDto.setMemberid(loginUser.getMemberid());
        updateDto.setName(name);
        updateDto.setEmail(email);
        
        // ⭐️ [핵심 수정] 기존 세션에 있던 정보들을 빠짐없이 옮겨 담아야 합니다!
        // 이걸 안 하면 수정 후에 학교 정보가 사라져서 "미입력"으로 뜹니다.
        updateDto.setPassword(loginUser.getPassword()); 
        updateDto.setRole(loginUser.getRole());
        updateDto.setVerified(loginUser.isVerified()); 
        
        updateDto.setSchool(loginUser.getSchool());     // 학교 유지
        updateDto.setMajor(loginUser.getMajor());       // 학과 유지
        updateDto.setStudentId(loginUser.getStudentId()); // 학번 유지

        // 3. DB 업데이트 (이름, 이메일만 수정)
        MemberDAO dao = new MemberDAO();
        boolean isSuccess = dao.updateMember(updateDto);

        PrintWriter out = response.getWriter();
        if (isSuccess) {
            // 4. 세션 덮어쓰기 (학교 정보가 포함된 새 객체로 갱신)
            session.setAttribute("memberId", updateDto);
            
            out.println("<script>");
            out.println("alert('프로필이 수정되었습니다.');");
            out.println("location.href='myPage.jsp';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('수정에 실패했습니다.');");
            out.println("history.back();");
            out.println("</script>");
        }
    }
}