// WishServlet.java 파일 전체를 덮어쓰세요.
package com.dongyang.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import com.dongyang.dao.ProductDAO;
import com.google.gson.Gson; // Gson 임포트

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/WishServlet") // ❗️ 이 부분이 정확해야 합니다.
public class WishServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Gson gson = new Gson();

    // GET 요청: 현재 찜 상태 확인
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String productIdStr = request.getParameter("productId");
        int productId = 0;
        
        try {
            productId = Integer.parseInt(productIdStr);
        } catch (NumberFormatException e) {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print("{\"isBookmarked\":false}");
            return;
        }

        ProductDAO dao = new ProductDAO();
        boolean isBookmarked = dao.isBookmarked(userId, productId);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print("{\"isBookmarked\":" + isBookmarked + "}");
        out.flush();
    }

    // POST 요청: 찜 토글
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // --- 1. JSON 데이터 읽기 ---
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        
        String userId = null;
        int productId = 0;
        String status = "";

        try {
            Map<String, Object> data = gson.fromJson(sb.toString(), Map.class);
            userId = (String) data.get("userId");
            productId = ((Double) data.get("productId")).intValue(); 
            
            ProductDAO dao = new ProductDAO();

            if (dao.isBookmarked(userId, productId)) {
                // 이미 찜 되어있으면 -> 삭제
                dao.removeBookmark(userId, productId);
                status = "removed";
            } else {
                // 찜 안되어있으면 -> 추가
                dao.addBookmark(userId, productId);
                status = "added";
            }
        
        } catch (Exception e) {
            e.printStackTrace();
            status = "error";
        }

        // --- 4. JSON 응답 반환 ---
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print("{\"status\":\"" + status + "\"}");
        out.flush();
    }
}