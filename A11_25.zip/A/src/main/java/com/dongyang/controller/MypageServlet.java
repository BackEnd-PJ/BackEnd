package com.dongyang.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

// 🚨 프로젝트 경로에 맞게 DAO와 DTO를 import 합니다.
import com.dongyang.dao.MemberDAO; 
import com.dongyang.dto.MemberDTO; 

/**
 * Servlet implementation class MypageServlet
 */
@WebServlet("/mypage")
public class MypageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public MypageServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 1. 세션에서 현재 로그인된 사용자 ID를 가져옵니다.
		HttpSession session = request.getSession();
		// "memberId"라는 세션 키를 사용한다고 가정합니다.
		String memberId = (String) session.getAttribute("memberId"); 

		// 2. 로그인 상태 확인 및 비로그인 시 처리
		if (memberId == null) {
			// 로그인하지 않은 경우, 로그인 페이지로 리다이렉트
			response.sendRedirect("login.jsp");
			return;
		}

		// 3. DAO를 통해 데이터베이스에서 회원 정보를 조회합니다.
		MemberDAO memberDao = new MemberDAO();
		// MemberDAO에 getMemberInfo(String memberid) 메서드가 구현되어 있어야 합니다.
		MemberDTO memberInfo = memberDao.getMemberInfo(memberId); 

		// 4. 조회된 정보를 View(JSP)로 전달하기 위해 Request 객체에 저장합니다.
		if (memberInfo != null) {
			// JSP에서 ${memberInfo.name} 등으로 접근할 수 있도록 request에 저장
			request.setAttribute("memberInfo", memberInfo);
			
			// 5. 마이페이지 JSP로 포워딩합니다. (View로 화면 제어 이동)
			request.getRequestDispatcher("mypage.jsp").forward(request, response);
		} else {
			// DB에서 정보를 찾지 못한 경우의 에러 처리
			request.setAttribute("errorMessage", "사용자 정보를 찾을 수 없습니다.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 마이페이지는 주로 GET 요청을 사용하지만, POST 요청이 들어오면 GET으로 처리하도록 위임
		doGet(request, response);
	}

}