package com.dongyang.dao;

import com.dongyang.dto.LocationDTO;
import com.dongyang.util.JdbcConnectUtil; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LocationDAO {
	public List<LocationDTO> getAllLocations() {
        // List 인터페이스로 선언하고 ArrayList 구현체를 사용합니다.
        List<LocationDTO> list = new ArrayList<>();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        // locationstbl 구조에 맞는 SQL 쿼리
        String sql = "select * from locationstbl;"; 

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                LocationDTO dto = new LocationDTO();
                
                // ResultSet에서 데이터를 읽어 DTO에 설정합니다.
                dto.setId(rs.getInt("id"));
                dto.setName(rs.getString("name"));
                dto.setAddr(rs.getString("addr"));
                
                // DB의 DOUBLE 타입 데이터를 DTO의 double 필드에 매핑
                dto.setLat(rs.getDouble("lat")); 
                dto.setLng(rs.getDouble("lng"));
                
                dto.setCategory(rs.getString("category"));
                
                list.add(dto);
            }
        } catch (SQLException e) {
            System.err.println("장소 정보 조회 중 SQL 오류 발생: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 자원 해제
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return list;
    }
    
    /**
     * 새로운 장소 정보를 DB에 삽입하는 메서드 (추가 기능)
     * @param dto 삽입할 장소 정보를 담은 DTO
     * @return 성공하면 true, 실패하면 false
     */
    public boolean addLocation(LocationDTO ldto) {
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;
        
        // id는 AUTO_INCREMENT이므로 제외합니다.
        String sql = "insert into locationstbl (name, addr, lat, lng, category) values (?, ?, ?, ?, ?);"; 
        
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            
            pstmt.setString(1, ldto.getName());
            pstmt.setString(2, ldto.getAddr());
            pstmt.setDouble(3, ldto.getLat());
            pstmt.setDouble(4, ldto.getLng());
            pstmt.setString(5, ldto.getCategory());
            
            result = pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("장소 정보 삽입 중 SQL 오류 발생: " + e.getMessage());
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
        return result > 0;
    }
}
