package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import com.dongyang.dao.EmailVerifyDAO;
import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.EmailVerifyDTO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/check_code.do")
public class CheckCodeServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // ⭐️ AJAX 응답을 위해 JSON 설정
        response.setContentType("application/json;charset=UTF-8");
        
        String email = request.getParameter("email");
        String code = request.getParameter("code");
        String school = request.getParameter("school");
        String major = request.getParameter("major");
        String studentId = request.getParameter("studentId");
        
        EmailVerifyDAO vdao = new EmailVerifyDAO();
        EmailVerifyDTO validDto = vdao.getValidCode(email, code);

        if (validDto != null) {
            // [인증 성공]
            MemberDAO mdao = new MemberDAO();
            HttpSession session = request.getSession();
            MemberDTO loginUser = (MemberDTO) session.getAttribute("memberId");

            if (loginUser != null) {
                // 로그인 상태: DB 및 세션 업데이트
                boolean updateResult = mdao.updateKakaoInfo(loginUser.getMemberid(), email, school, major, studentId);

                if (updateResult) {
                    loginUser.setEmail(email);
                    loginUser.setSchool(school);
                    loginUser.setMajor(major);
                    loginUser.setStudentId(studentId);
                    loginUser.setVerified(true);
                    session.setAttribute("memberId", loginUser);
                    
                    // ⭐️ 성공 JSON 응답
                    response.getWriter().write("{\"status\": \"success\"}");
                } else {
                    // DB 업데이트 실패
                    response.getWriter().write("{\"status\": \"fail\"}");
                }
            } else {
                // 비로그인 상태 (혹시 모를 예외)
                mdao.activateMember(email);
                session.removeAttribute("verify_email");
                response.getWriter().write("{\"status\": \"success\"}");
            }
            
        } else {
            // ⭐️ [인증 실패] JSON 응답 (모달을 유지하기 위함)
            response.getWriter().write("{\"status\": \"fail\"}");
        }
    }
}