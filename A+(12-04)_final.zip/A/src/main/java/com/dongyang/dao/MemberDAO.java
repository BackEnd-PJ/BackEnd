package com.dongyang.dao;

import java.sql.*;
import java.util.*;

import com.dongyang.dto.MemberDTO;
import com.dongyang.util.JdbcConnectUtil;

public class MemberDAO {
	// ✅ 로그인 체크 메서드 (SELECT)
	public MemberDTO loginCheck(String memberid, String password) {
		
			Connection con=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			MemberDTO loginCheck=null;
			try {
				con=JdbcConnectUtil.getConnection();
				// ⭐️ SQL: ID와 PW가 일치하는 회원을 찾습니다.
				pstmt=con.prepareStatement("select * from membertbl where memberid=? and password=?;");
				pstmt.setString(1, memberid);
				pstmt.setString(2, password);		
				
				rs=pstmt.executeQuery();
				if (rs.next()) {
		            // 결과가 있으면 (로그인 성공) DTO 객체에 DB에서 가져온 정보를 설정합니다.
					loginCheck = new MemberDTO();
					loginCheck.setMemberid(rs.getString("memberid"));
					loginCheck.setPassword(rs.getString("password"));
		            
		            // ⭐️ DB에서 읽어온 실제 역할(Role)을 설정합니다.
					loginCheck.setRole(rs.getString("role")); 
					loginCheck.setName(rs.getString("name"));
					loginCheck.setEmail(rs.getString("email"));
					loginCheck.setVerified(rs.getBoolean("is_verified"));
					loginCheck.setSchool(rs.getString("school"));
		            loginCheck.setMajor(rs.getString("major"));
		            loginCheck.setStudentId(rs.getString("student_id"));
		            loginCheck.setGpa(rs.getDouble("gpa"));
		        }
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				JdbcConnectUtil.close(con, pstmt, rs);
			}
			return loginCheck;
	}
	
	// ✅ 회원가입 메서드 (INSERT)
	public int registerMember(MemberDTO mdto) {
	    int result = 0;
	    Connection con = null;
	    PreparedStatement pstmt = null;

	    String id = mdto.getMemberid();
	    String pw = mdto.getPassword();
	    String name = mdto.getName();
	    String email = mdto.getEmail();
	    String school = mdto.getSchool();
	    String major = mdto.getMajor();
	    String studentid = mdto.getStudentId();
	    
	    // ⭐️ SQL: 회원 정보를 DB에 삽입합니다.
	    String sql = "INSERT INTO memberTbl (memberid, password, name, email, school, major, student_id, role, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 'user', 1)";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, id); 
	        pstmt.setString(2, pw); 
	        pstmt.setString(3, name); 
	        pstmt.setString(4, email);
	        pstmt.setString(5, school);
	        pstmt.setString(6, major);
	        pstmt.setString(7, studentid);
	        
	        result = pstmt.executeUpdate(); // 1이 반환되면 성공

	    } catch (SQLException e) {
	        System.out.println("!! 회원가입 DB 처리 중 에러");
	        e.printStackTrace();
	    } finally {
	    	JdbcConnectUtil.close(con, pstmt); 
	    }
	    
	    return result;
	}
	
	/**
	 * 비밀번호 변경 메서드
	 */
	public boolean updatePassword(String memberId, String newPassword) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    String sql = "UPDATE memberTbl SET password = ? WHERE memberid = ?";
	    boolean result = false;

	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, newPassword);
	        pstmt.setString(2, memberId);

	        int count = pstmt.executeUpdate();
	        if (count > 0) result = true;

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt);
	    }
	    return result;
	}
	
	/**
     *  회원 상태를 '인증됨'으로 업데이트
     */
    public boolean activateMember(String email) {
        String sql = "UPDATE memberTbl SET is_verified = 1 WHERE email = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, email);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
    
	
	/**
     * [관리자] 모든 회원 목록을 조회합니다.
     */
	public List<MemberDTO> getAllMembers() {
        List<MemberDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM membertbl ORDER BY role DESC, memberid ASC";
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                MemberDTO dto = new MemberDTO();
                dto.setMemberid(rs.getString("memberid"));
                dto.setName(rs.getString("name"));
                dto.setEmail(rs.getString("email"));
                dto.setRole(rs.getString("role"));
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return list;
    }
	
	/**
     * [관리자] ID로 회원을 삭제합니다.
     * (카카오 사용자는 memberid가 숫자 문자열입니다)
     */
    public boolean deleteMember(String memberId) {
        String sql = "DELETE FROM membertbl WHERE memberid = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, memberId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
    
	/**
     * 카카오 ID로 회원을 조회하고, 없으면 새로 가입시키는 메서드
     * @param kakaoUser (카카오에서 받은 id, nickname, email이 담긴 DTO)
     * @return DB에 저장된 최종 회원 정보가 담긴 MemberDTO 객체
     */
    public MemberDTO findOrCreateKakaoUser(MemberDTO kakaoUser) {
        // 1. 기존 회원인지 조회
        String selectSql = "SELECT * FROM memberTbl WHERE memberid = ?";
        
        try (Connection conn = JdbcConnectUtil.getConnection();
             PreparedStatement pstmtSelect = conn.prepareStatement(selectSql)) {
            
            pstmtSelect.setString(1, kakaoUser.getMemberid());
            try (ResultSet rs = pstmtSelect.executeQuery()) {
                if (rs.next()) {
                    // 이미 가입된 회원 -> DB에 저장된 정보(인증 여부 포함)를 반환
                    MemberDTO existingUser = new MemberDTO();
                    existingUser.setMemberid(rs.getString("memberid"));
                    existingUser.setName(rs.getString("name")); 
                    existingUser.setEmail(rs.getString("email"));
                    existingUser.setRole(rs.getString("role"));
                    existingUser.setVerified(rs.getBoolean("is_verified")); // DB의 인증 상태를 그대로 가져옴
                    existingUser.setGpa(rs.getDouble("gpa"));
                    return existingUser;
                }
            }

            // 2. 신규 가입 (INSERT)
            // ⭐️ [수정 1] is_verified를 '0'(미인증)으로 저장합니다.
            String insertSql = "INSERT INTO memberTbl (memberid, password, name, email, school, major, student_id, role, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 'user', 0)";
            
            try (PreparedStatement pstmtInsert = conn.prepareStatement(insertSql)) {
                pstmtInsert.setString(1, kakaoUser.getMemberid()); 
                pstmtInsert.setString(2, "kakao_login_password"); 
                
                // [name]
                pstmtInsert.setString(3, kakaoUser.getName() != null ? kakaoUser.getName() : "카카오사용자");
                
                // [email] null 방지 처리 (빈 문자열)
                String safeEmail = (kakaoUser.getEmail() != null) ? kakaoUser.getEmail() : "";
                pstmtInsert.setString(4, safeEmail); 
                
                // [school, major] 미입력 처리
                pstmtInsert.setString(5, "미입력"); 
                pstmtInsert.setString(6, "미입력"); 
                
                // [student_id] 임시 값
                pstmtInsert.setString(7, "kakao_" + kakaoUser.getMemberid()); 
                
                if (pstmtInsert.executeUpdate() > 0) {
                    // ⭐️ [수정 2] 세션 객체에도 '미인증' 상태로 설정
                    kakaoUser.setVerified(false); 
                    return kakaoUser;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean updateMember(MemberDTO dto) {
        Connection con = null;
        PreparedStatement pstmt = null;
        // 🌟 비밀번호 컬럼 제외함
        String sql = "UPDATE memberTbl SET name=?, email=? WHERE memberid=?";
        boolean result = false;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getEmail());
            pstmt.setString(3, dto.getMemberid());

            int count = pstmt.executeUpdate();
            if (count > 0) result = true;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
        return result;
    }
    
    /**
     * 카카오 로그인 사용자의 추가 정보(이메일, 학교, 학과, 학번) 업데이트 및 인증 처리
     */
    public boolean updateKakaoInfo(String memberId, String email, String school, String major, String studentId) {
    	String sql = "UPDATE memberTbl SET email = ?, school = ?, major = ?, student_id = ?, is_verified = 1 WHERE memberid = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, school);
            pstmt.setString(3, major);
            pstmt.setString(4, studentId);
            pstmt.setString(5, memberId); 
            
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
    
 // ID로 최신 회원 정보 조회 (학점 갱신용)
    public MemberDTO getMemberById(String memberId) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        MemberDTO member = null;
        
        try {
            con = JdbcConnectUtil.getConnection();
            String sql = "SELECT * FROM memberTbl WHERE memberid = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, memberId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                member = new MemberDTO();
                member.setMemberid(rs.getString("memberid"));
                member.setPassword(rs.getString("password"));
                member.setName(rs.getString("name"));
                member.setEmail(rs.getString("email"));
                member.setSchool(rs.getString("school"));
                member.setMajor(rs.getString("major"));
                member.setStudentId(rs.getString("student_id"));
                member.setRole(rs.getString("role"));
                member.setVerified(rs.getBoolean("is_verified"));
                // 최신 학점 가져오기
                member.setGpa(rs.getDouble("gpa"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return member;
    }
    
    
}