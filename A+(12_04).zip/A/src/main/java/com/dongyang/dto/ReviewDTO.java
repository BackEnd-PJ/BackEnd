package com.dongyang.dto;

import java.sql.Timestamp;

public class ReviewDTO {
	private int id;
	private String reviewerId; // 후기 남긴 사람
	private String sellerId;   // 판매자 (후기 받은 사람)
	private int productId;
	private double rating;     // 평점 (1.0 ~ 4.5)
	private String content;    // 후기 내용
	private Timestamp createdAt;
	
	// ⭐️ 추가: 화면 표시용 (조인해서 가져올 경우 사용)
	private String reviewerName; // 후기 남긴 사람 닉네임
	private String productName;  // 상품명
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReviewerId() {
		return reviewerId;
	}
	public void setReviewerId(String reviewerId) {
		this.reviewerId = reviewerId;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	public String getReviewerName() {
		return reviewerName;
	}
	public void setReviewerName(String reviewerName) {
		this.reviewerName = reviewerName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
}