package com.dongyang.controller;

import java.io.IOException;
import com.dongyang.dao.NotificationDAO;
import com.dongyang.dto.MemberDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/purchaseRequest.do")
public class PurchaseRequestServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        
        // 1. 로그인 확인
        HttpSession session = request.getSession();
        MemberDTO buyer = (MemberDTO) session.getAttribute("memberId");
        
        if (buyer == null) {
            response.getWriter().write("{\"status\": \"not_login\"}");
            return;
        }

        // 2. 파라미터 수신
        String sellerId = request.getParameter("sellerId");
        int productId = Integer.parseInt(request.getParameter("productId"));
        String productName = request.getParameter("productName");
        
        // 본인 물건 구매 방지
        if(buyer.getMemberid().equals(sellerId)) {
             response.getWriter().write("{\"status\": \"self_error\"}");
             return;
        }

        // 3. ⭐️ [수정] 알림 메시지에 구매자 이메일 추가
        String message = "구매를 희망합니다!";
        
        NotificationDAO dao = new NotificationDAO();
        boolean success = dao.sendNotification(sellerId, buyer.getMemberid(), productId, message);
        
        // 4. 결과 응답
        if (success) {
            response.getWriter().write("{\"status\": \"success\"}");
        } else {
            response.getWriter().write("{\"status\": \"fail\"}");
        }
    }
}