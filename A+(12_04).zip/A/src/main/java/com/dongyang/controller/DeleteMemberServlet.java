package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/deleteMember.do")
public class DeleteMemberServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        
        HttpSession session = request.getSession();
        MemberDTO loginUser = (MemberDTO) session.getAttribute("memberId");

        // 로그인 안 된 상태면 로그인 페이지로
        if (loginUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 기존 DAO 사용
        MemberDAO dao = new MemberDAO();
        boolean isDeleted = dao.deleteMember(loginUser.getMemberid());
        
        PrintWriter out = response.getWriter();
        if (isDeleted) {
            session.invalidate(); // 세션 삭제 (로그아웃)
            out.println("<script>");
            out.println("alert('회원 탈퇴가 완료되었습니다.');");
            out.println("location.href='main.jsp';"); // 메인으로 이동
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('탈퇴 처리에 실패했습니다. 관리자에게 문의하세요.');");
            out.println("history.back();");
            out.println("</script>");
        }
    }
}