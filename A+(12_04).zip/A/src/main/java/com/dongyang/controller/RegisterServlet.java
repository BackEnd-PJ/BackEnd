package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/register.do")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // 1. 파라미터 수신
        String id = request.getParameter("id");
        String password = request.getParameter("pw");
        String name = request.getParameter("name"); // 닉네임
        String email = request.getParameter("email");
        String school = request.getParameter("school");
        String major = request.getParameter("major");
        String studentId = request.getParameter("studentId");
        
        // 2. DTO 설정
        MemberDTO mdto = new MemberDTO();
        mdto.setMemberid(id);
        mdto.setPassword(password);
        mdto.setName(name);
        mdto.setEmail(email);
        mdto.setSchool(school);
        mdto.setMajor(major);
        mdto.setStudentId(studentId);
        
        // ⭐️ 핵심: 1단계 화면에서 이미 인증을 완료하고 넘어왔으므로, 
        // 여기서는 바로 '인증됨(true)' 상태로 DB에 저장합니다.
        mdto.setVerified(true); 
        
        // 3. DB 저장
        MemberDAO mdao = new MemberDAO();
        int result = mdao.registerMember(mdto); 
         
        if(result == 1) { 
            // 4. 회원가입 성공 -> 로그인 페이지로 바로 이동
            // (더 이상 여기서 이메일을 보내거나 verify_code.jsp로 가지 않습니다)
            response.sendRedirect("login.jsp?register=success");

        } else { 
            // 5. 회원가입 실패 (ID 중복 등)
             response.sendRedirect("register.jsp?error=duplicate");
        }
    }
}