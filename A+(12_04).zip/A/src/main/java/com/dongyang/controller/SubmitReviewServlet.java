package com.dongyang.controller;

import java.io.IOException;

import com.dongyang.dao.NotificationDAO;
import com.dongyang.dao.ProductDAO; // 추가
import com.dongyang.dao.ReviewDAO;
import com.dongyang.dto.MemberDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/submitReview.do")
public class SubmitReviewServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        MemberDTO reviewer = (MemberDTO) session.getAttribute("memberId");
        
        if(reviewer == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String sellerId = request.getParameter("sellerId");
        int productId = Integer.parseInt(request.getParameter("productId"));
        double rating = Double.parseDouble(request.getParameter("rating"));
        String content = request.getParameter("content");
        
        // 1. 후기 등록
        ReviewDAO reviewDao = new ReviewDAO();
        reviewDao.insertReview(reviewer.getMemberid(), sellerId, productId, rating, content);
        
        // 2. ⭐️ [추가] 상품 상태를 '판매 완료(SOLD)'로 변경
        ProductDAO productDao = new ProductDAO();
        productDao.updateProductStatus(productId, "SOLD");
        
        // 3. ⭐️ [추가] 해당 거래 관련 알림 삭제 (더 이상 '후기 작성' 버튼을 띄울 필요 없으므로)
        NotificationDAO notiDao = new NotificationDAO();
        notiDao.deleteNotificationByProduct(reviewer.getMemberid(), productId);
        
        // 4. 마이페이지로 이동
        response.sendRedirect("myPage.jsp");
    }
}