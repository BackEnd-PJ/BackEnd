package com.dongyang.dao;

import com.dongyang.dto.ProductDTO;
import com.dongyang.util.JdbcConnectUtil; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; // ⭐️ 추가
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	
	/**
	 * productstbl 테이블에서 모든 상품 정보를 가져옵니다.
	 */
	public List<ProductDTO> getAllProducts() {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl ORDER BY id DESC"; // 최신순 정렬

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getLong("price")); 
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));	
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setImageUrl(rs.getString("image_url")); 
				dto.setDescription(rs.getString("description"));
				
				// 🌟 [여기가 수정됨!] 이 줄을 꼭 추가해야 마이페이지에 뜹니다.
				dto.setMemberId(rs.getString("member_id")); 
				
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 정보 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	// ⭐️ [수정] 다중 이미지 처리를 위한 addProduct 메서드
	public boolean addProduct(ProductDTO pdto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmtImg = null; // 이미지 저장용 PreparedStatement
		ResultSet rs = null;
		boolean result = false;
		
		// 1. 상품 기본 정보 저장 (대표 이미지는 image_url 컬럼에 저장)
		String sqlProduct = "INSERT INTO productstbl (name, price, addr, lat, lng, category, image_url, description, member_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		// 2. 추가 이미지 저장 (순서 포함)
	    String sqlImage = "INSERT INTO product_images (product_id, image_url, image_order) VALUES (?, ?, ?)";
		
		try {
			con = JdbcConnectUtil.getConnection();
			con.setAutoCommit(false); // ⭐️ 트랜잭션 시작
			
			// 상품 정보 INSERT (생성된 키 반환 요청)
			pstmt = con.prepareStatement(sqlProduct, Statement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, pdto.getName());
			pstmt.setLong(2, pdto.getPrice());
			pstmt.setString(3, pdto.getAddr());
			pstmt.setDouble(4, pdto.getLat());
			pstmt.setDouble(5, pdto.getLng());
			pstmt.setString(6, pdto.getCategory());
			pstmt.setString(7, pdto.getImageUrl()); // 대표 이미지 (썸네일용)
			pstmt.setString(8, pdto.getDescription());
			pstmt.setString(9, pdto.getMemberId()); 
			
			int affectedRows = pstmt.executeUpdate();

	        if (affectedRows > 0) {
	            // 2. 생성된 상품 ID (Auto Increment 값) 가져오기
	            rs = pstmt.getGeneratedKeys();
	            if (rs.next()) {
	                int productId = rs.getInt(1);

	                // 3. product_images 테이블에 전체 이미지 리스트 저장
	                if (pdto.getImageList() != null && !pdto.getImageList().isEmpty()) {
	                    pstmtImg = con.prepareStatement(sqlImage);
	                    
	                    for (int i = 0; i < pdto.getImageList().size(); i++) {
	                        pstmtImg.setInt(1, productId);
	                        pstmtImg.setString(2, pdto.getImageList().get(i));
	                        pstmtImg.setInt(3, i); // 이미지 순서 (0, 1, 2...)
	                        pstmtImg.addBatch();   // 배치에 추가
	                    }
	                    pstmtImg.executeBatch();   // 일괄 실행
	                }
	                
	                con.commit(); // ⭐️ 모든 작업 성공 시 커밋
	                result = true;
	            }
	        } else {
	            con.rollback(); // 실패 시 롤백
	        }
			
		} catch (SQLException e) {
			System.err.println("상품 정보 삽입 중 SQL 오류 발생: " + e.getMessage());
			try { if (con != null) con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
	        e.printStackTrace();
		} finally {
			// 자원 해제
			JdbcConnectUtil.close(con, pstmt, rs);
			if (pstmtImg != null) try { pstmtImg.close(); } catch(Exception e){}
		}
		return result;
	}
	
	//관리자:상품관리
	public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM productstbl WHERE id = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, productId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
	
	
	/**
	 * 찜 목록 조회 (bookmarkstbl과 productstbl JOIN)
	 */
	public List<ProductDTO> getBookMarkByUserId(String userId) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT p.* " +
					 "FROM productstbl p " +
					 "JOIN bookmarkstbl b ON p.id = b.product_id " +
					 "WHERE b.member_id = ?"; 

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("찜 목록(bookmark) 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	/**
	 * 상품 이름(name)으로 상품을 검색하는 메서드 (LIKE 사용)
	 */
	public List<ProductDTO> searchProductsByName(String keyword) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl WHERE name LIKE ?";

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + keyword + "%"); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 검색(searchProductsByName) 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	// ⭐️ [수정] 상품 상세 조회 시 이미지 목록도 함께 가져오도록 수정
	public ProductDTO getProductById(int productId) {
	    ProductDTO product = null;
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	    // ⭐️ [수정] JOIN 쿼리 사용
	    // productstbl(p)과 memberTbl(m)을 연결하여 판매자의 닉네임(m.name)을 가져옴
	    String sql = "SELECT p.*, m.name AS seller_name " +
	                 "FROM productstbl p " +
	                 "LEFT JOIN memberTbl m ON p.member_id = m.memberid " +
	                 "WHERE p.id = ?";
	    
	    try {
	        con = JdbcConnectUtil.getConnection(); 
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, productId);
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            product = new ProductDTO();
	            
	            product.setId(rs.getInt("id"));
	            product.setName(rs.getString("name"));
	            product.setPrice(rs.getLong("price"));
	            product.setDescription(rs.getString("description"));
	            product.setImageUrl(rs.getString("image_url"));
	            product.setCategory(rs.getString("category"));
	            product.setAddr(rs.getString("addr")); 
	            product.setLat(rs.getDouble("lat"));
	            product.setLng(rs.getDouble("lng"));
	            product.setMemberId(rs.getString("member_id")); 
	            
	            // ⭐️ [추가] 닉네임 설정
	            // 만약 탈퇴한 회원이면 닉네임이 null일 수 있으므로 기본값 처리
	            String nick = rs.getString("seller_name");
	            product.setSellerName(nick != null ? nick : "알수없음"); 
	            
	            // (이미지 리스트 조회 로직 유지)
	            String imgSql = "SELECT image_url FROM product_images WHERE product_id = ? ORDER BY image_order ASC";
	            PreparedStatement pstmtImg = null;
	            ResultSet rsImg = null;
	            try {
	                pstmtImg = con.prepareStatement(imgSql);
	                pstmtImg.setInt(1, productId);
	                rsImg = pstmtImg.executeQuery();
	                
	                List<String> images = new ArrayList<>();
	                while(rsImg.next()) {
	                    images.add(rsImg.getString("image_url"));
	                }
	                product.setImageList(images);
	                
	            } catch(Exception e) {
	                e.printStackTrace();
	            } finally {
	                if(rsImg != null) try { rsImg.close(); } catch(Exception e) {}
	                if(pstmtImg != null) try { pstmtImg.close(); } catch(Exception e) {}
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, rs);
	    }
	    return product;
	}
	
	public boolean isBookmarked(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    boolean exists = false;
	    
	    String sql = "SELECT COUNT(*) FROM bookmarkstbl WHERE member_id = ? AND product_id = ?";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            if (rs.getInt(1) > 0) {
	                exists = true; 
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, rs);
	    }
	    return exists;
	}

	/**
	 * 찜 목록(bookmarkstbl)에 데이터를 추가하는 메서드
	 */
	public boolean addBookmark(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    int result = 0;
	    
	    String sql = "INSERT INTO bookmarkstbl (member_id, product_id) VALUES (?, ?)";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        result = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        System.err.println("찜 추가 오류(이미 존재할 수 있음): " + e.getMessage());
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, null);
	    }
	    
	    return result > 0;
	}

	/**
	 * 찜 목록(bookmarkstbl)에서 데이터를 삭제하는 메서드
	 */
	public boolean removeBookmark(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    int result = 0;
	    
	    String sql = "DELETE FROM bookmarkstbl WHERE member_id = ? AND product_id = ?";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        result = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, null);
	    }
	    return result > 0;
	}
}