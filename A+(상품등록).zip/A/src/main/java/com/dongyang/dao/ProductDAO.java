package com.dongyang.dao;

import com.dongyang.dto.ProductDTO; // ❗️ ProductDTO를 사용
import com.dongyang.util.JdbcConnectUtil; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	
	/**
	 * productstbl 테이블에서 모든 상품 정보를 가져옵니다.
	 * @return ProductDTO 객체로 채워진 List
	 */
	public List<ProductDTO> getAllProducts() {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		// ❗️ [수정] productstbl에서 모든 필드를 조회합니다.
		String sql = "SELECT id, name, price, addr, lat, lng, category, image_url FROM productstbl;";	

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				
				// ResultSet에서 데이터를 읽어 DTO에 설정합니다.
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price")); // ❗️ [추가] 가격 설정
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));	
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setImageUrl(rs.getString("image_url")); // ❗️ [추가] 이미지 경로 설정
				
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 정보 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			// 자원 해제
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	/**
	 * 새로운 상품 정보를 DB에 삽입하는 메서드
	 * @param pdto 삽입할 상품 정보를 담은 DTO
	 * @return 성공하면 true, 실패하면 false
	 */
	public boolean addProduct(ProductDTO pdto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		// ❗️ [수정] productstbl 및 추가된 컬럼에 맞게 SQL 변경
		String sql = "INSERT INTO productstbl (name, price, addr, lat, lng, category, image_url) VALUES (?, ?, ?, ?, ?, ?, ?);";	
		
		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, pdto.getName());
			pstmt.setInt(2, pdto.getPrice()); // ❗️ [추가] 가격
			pstmt.setString(3, pdto.getAddr());
			pstmt.setDouble(4, pdto.getLat());
			pstmt.setDouble(5, pdto.getLng());
			pstmt.setString(6, pdto.getCategory());
			pstmt.setString(7, pdto.getImageUrl()); // ❗️ [추가] 이미지 경로
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("상품 정보 삽입 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, null);
		}
		return result > 0;
	}
}