package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

import com.dongyang.dao.ProductDAO;
import com.dongyang.dto.ProductDTO;
import com.google.gson.Gson; // Gson 라이브러리 필요 (기존에 있음)

@WebServlet("/sise.do")
public class SiseServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String keyword = request.getParameter("keyword");
        
        // 1. 기본값 설정
        if (keyword == null) keyword = "";
        
        ProductDAO dao = new ProductDAO();
        List<ProductDTO> productList = new ArrayList<>();
        
        // 2. 검색어가 있을 때만 DB 조회
        if (!keyword.trim().isEmpty()) {
            productList = dao.searchProductsByName(keyword);
        }
        
        // 3. 통계 계산 (평균 가격, 최고가, 최저가)
        long totalPrice = 0;
        long avgPrice = 0;
        long minPrice = 0;
        long maxPrice = 0;
        
        if (!productList.isEmpty()) {
            minPrice = productList.get(0).getPrice();
            
            for (ProductDTO p : productList) {
                totalPrice += p.getPrice();
                if (p.getPrice() < minPrice) minPrice = p.getPrice();
                if (p.getPrice() > maxPrice) maxPrice = p.getPrice();
            }
            avgPrice = totalPrice / productList.size();
        }

        // 4. 차트용 데이터 (JSON 변환)
        // 상품명 리스트 (Labels)
        List<String> labels = productList.stream()
                                         .map(ProductDTO::getName)
                                         .collect(Collectors.toList());
        // 가격 리스트 (Data)
        List<Long> prices = productList.stream()
                                       .map(ProductDTO::getPrice)
                                       .collect(Collectors.toList());

        Gson gson = new Gson();
        String jsonLabels = gson.toJson(labels);
        String jsonPrices = gson.toJson(prices);

        // 5. 결과 저장
        request.setAttribute("keyword", keyword);
        request.setAttribute("productList", productList); // 하단 목록용
        request.setAttribute("avgPrice", avgPrice);       // 평균 시세
        request.setAttribute("count", productList.size());// 검색 건수
        
        // 차트용 데이터
        request.setAttribute("jsonLabels", jsonLabels);
        request.setAttribute("jsonPrices", jsonPrices);

        // 6. JSP로 이동
        request.getRequestDispatcher("sise.jsp").forward(request, response);
    }
}