package com.dongyang.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.dongyang.dao.EmailVerifyDAO;
import com.dongyang.dto.EmailVerifyDTO;

@WebServlet("/verifyCodeAjax.do")
public class VerifyCodeAjaxServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String code = request.getParameter("code");
        
        EmailVerifyDAO vdao = new EmailVerifyDAO();
        EmailVerifyDTO validDto = vdao.getValidCode(email, code);

        response.setContentType("application/json;charset=UTF-8");
        
        if (validDto != null) {
            response.getWriter().write("{\"valid\": true}");
        } else {
            response.getWriter().write("{\"valid\": false}");
        }
    }
}