package com.dongyang.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import com.dongyang.dto.NotificationDTO;
import com.dongyang.util.JdbcConnectUtil;

public class NotificationDAO {
    // 알림 전송
    public boolean sendNotification(String receiverId, String senderId, int productId, String message) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "INSERT INTO notifications (receiver_id, sender_id, product_id, message) VALUES (?, ?, ?, ?)";
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, receiverId);
            pstmt.setString(2, senderId);
            pstmt.setInt(3, productId);
            pstmt.setString(4, message);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
    }
    
 // 1. 안 읽은 알림 개수 가져오기 (헤더 뱃지용)
    public int countUnread(String receiverId) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;
        try {
            con = JdbcConnectUtil.getConnection();
            String sql = "SELECT COUNT(*) FROM notifications WHERE receiver_id = ? AND is_read = 0";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, receiverId);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return count;
    }

 // 2. 내 알림 목록 조회 (최신순) - JOIN 쿼리 사용
    public List<NotificationDTO> getMyNotifications(String receiverId) {
        List<NotificationDTO> list = new ArrayList<>();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        // ⭐️ 수정된 SQL: 알림 + 회원(이름) + 상품(상품명) 조인
        String sql = "SELECT n.*, m.name AS sender_name, p.name AS product_name " +
                     "FROM notifications n " +
                     "JOIN memberTbl m ON n.sender_id = m.memberid " +
                     "JOIN productstbl p ON n.product_id = p.id " +
                     "WHERE n.receiver_id = ? " +
                     "ORDER BY n.created_at DESC";
                     
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, receiverId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                NotificationDTO dto = new NotificationDTO();
                dto.setId(rs.getInt("id"));
                dto.setReceiverId(rs.getString("receiver_id"));
                dto.setSenderId(rs.getString("sender_id"));
                dto.setProductId(rs.getInt("product_id"));
                dto.setMessage(rs.getString("message"));
                dto.setRead(rs.getBoolean("is_read"));
                dto.setCreatedAt(rs.getTimestamp("created_at"));
                
                // ⭐️ DB에서 가져온 이름과 상품명을 DTO에 저장
                dto.setSenderName(rs.getString("sender_name"));
                dto.setProductName(rs.getString("product_name"));
                
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, rs);
        }
        return list;
    }
    
    // ⭐️ [신규 추가] 특정 상품에 대한 알림 삭제 (후기 작성 완료 시 호출)
    public void deleteNotificationByProduct(String userId, int productId) {
        Connection con = null;
        PreparedStatement pstmt = null;
        // 내(userId)가 받은 알림 중, 해당 상품(productId)에 관련된 알림을 삭제
        String sql = "DELETE FROM notifications WHERE receiver_id = ? AND product_id = ?";
        
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, userId);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
    }
    
    // ⭐️ [신규] 알림 ID로 개별 삭제 (X 버튼 클릭 시)
    public boolean deleteNotification(int id) {
        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "DELETE FROM notifications WHERE id = ?";
        
        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            JdbcConnectUtil.close(con, pstmt, null);
        }
    }
    
}