package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/register.do")
public class RegisterServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
	     String password=request.getParameter("pw");

	     MemberDTO mdto=new MemberDTO();
	     mdto.setMemberid(id);
	     mdto.setPassword(password);
	     
	     MemberDAO mdao=new MemberDAO();
	     int result=mdao.registerMember(mdto);
	     
	     if(result==1) {
	    	 response.sendRedirect("main.jsp");
	     }
	     else {
	    	 response.sendRedirect("register.jsp");
	     }
	}

}
