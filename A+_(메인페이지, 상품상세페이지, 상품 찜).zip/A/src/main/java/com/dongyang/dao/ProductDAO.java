package com.dongyang.dao;

import com.dongyang.dto.ProductDTO;
import com.dongyang.util.JdbcConnectUtil; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	
	/**
	 * productstbl 테이블에서 모든 상품 정보를 가져옵니다.
	 */
	public List<ProductDTO> getAllProducts() {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl;";	

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getLong("price")); 
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));	
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setImageUrl(rs.getString("image_url")); 
				dto.setDescription(rs.getString("description"));
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 정보 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	public boolean addProduct(ProductDTO pdto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
        // [수정] SQL에 member_id 컬럼 추가
		String sql = "INSERT INTO productstbl (name, price, addr, lat, lng, category, image_url, description, member_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";	
		
		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, pdto.getName());
			pstmt.setLong(2, pdto.getPrice());
			pstmt.setString(3, pdto.getAddr());
			pstmt.setDouble(4, pdto.getLat());
			pstmt.setDouble(5, pdto.getLng());
			pstmt.setString(6, pdto.getCategory());
			pstmt.setString(7, pdto.getImageUrl());
			pstmt.setString(8, pdto.getDescription());
			pstmt.setString(9, pdto.getMemberId()); // [수정] memberId 값 설정
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("상품 정보 삽입 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, null);
		}
		return result > 0;
	}
	
	//관리자:상품관리
	public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM productstbl WHERE id = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, productId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
	

	/**
	 * 찜 목록 조회 (bookmarkstbl과 productstbl JOIN)
	 */
	public List<ProductDTO> getBookMarkByUserId(String userId) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT p.* " +
					 "FROM productstbl p " +
					 "JOIN bookmarkstbl b ON p.id = b.product_id " +
					 "WHERE b.member_id = ?"; 

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("찜 목록(bookmark) 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	/**
	 * 상품 이름(name)으로 상품을 검색하는 메서드 (LIKE 사용)
	 */
	public List<ProductDTO> searchProductsByName(String keyword) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl WHERE name LIKE ?";

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + keyword + "%"); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 검색(searchProductsByName) 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	// ProductDAO.java 파일의 getProductById 메서드를 이걸로 교체하세요.

	public ProductDTO getProductById(int productId) {
	    ProductDTO product = null;
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	    // [수정] 테이블명(productstbl)과 컬럼명(id)을 DAO에 맞게 수정
	    String sql = "SELECT * FROM productstbl WHERE id = ?"; 
	    
	    try {
	        con = JdbcConnectUtil.getConnection(); 
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, productId);
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            product = new ProductDTO();
	            
	            // [수정] DTO의 실제 메서드(setId, setAddr 등)로 수정
	            product.setId(rs.getInt("id"));
	            product.setName(rs.getString("name"));
	            product.setPrice(rs.getLong("price"));
	            product.setDescription(rs.getString("description"));
	            product.setImageUrl(rs.getString("image_url"));
	            product.setCategory(rs.getString("category"));
	            product.setAddr(rs.getString("addr")); 
	            product.setLat(rs.getDouble("lat"));
	            product.setLng(rs.getDouble("lng"));
	            product.setMemberId(rs.getString("member_id")); 
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, rs);
	    }
	    return product;
	}
	public boolean isBookmarked(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    boolean exists = false;
	    
	    String sql = "SELECT COUNT(*) FROM bookmarkstbl WHERE member_id = ? AND product_id = ?";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            if (rs.getInt(1) > 0) {
	                exists = true; 
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, rs);
	    }
	    return exists;
	}

	/**
	 * 찜 목록(bookmarkstbl)에 데이터를 추가하는 메서드
	 */
	public boolean addBookmark(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    int result = 0;
	    
	    String sql = "INSERT INTO bookmarkstbl (member_id, product_id) VALUES (?, ?)";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        result = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        System.err.println("찜 추가 오류(이미 존재할 수 있음): " + e.getMessage());
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, null);
	    }
	    
	    return result > 0;
	}

	/**
	 * 찜 목록(bookmarkstbl)에서 데이터를 삭제하는 메서드
	 */
	public boolean removeBookmark(String memberId, int productId) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    int result = 0;
	    
	    String sql = "DELETE FROM bookmarkstbl WHERE member_id = ? AND product_id = ?";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, memberId);
	        pstmt.setInt(2, productId);
	        result = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        JdbcConnectUtil.close(con, pstmt, null);
	    }
	    return result > 0;
	}
}