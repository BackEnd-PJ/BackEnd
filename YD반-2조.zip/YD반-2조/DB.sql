CREATE DATABASE  IF NOT EXISTS `porjectdb` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `porjectdb`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: porjectdb
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmarkstbl`
--


DROP TABLE IF EXISTS `bookmarkstbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarkstbl` (
  `bookmark_id` int NOT NULL AUTO_INCREMENT,
  `member_id` varchar(50) NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`bookmark_id`),
  UNIQUE KEY `uk_member_product` (`member_id`,`product_id`),
  KEY `fk_bookmark_product` (`product_id`),
  CONSTRAINT `fk_bookmark_member` FOREIGN KEY (`member_id`) REFERENCES `membertbl` (`memberid`) ON DELETE CASCADE,
  CONSTRAINT `fk_bookmark_product` FOREIGN KEY (`product_id`) REFERENCES `productstbl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarkstbl`
--

LOCK TABLES `bookmarkstbl` WRITE;
/*!40000 ALTER TABLE `bookmarkstbl` DISABLE KEYS */;
INSERT INTO `bookmarkstbl` VALUES (1,'yeonho2010',1),(2,'yeonho2010',2),(3,'yeonho2010',3),(4,'yeonho2010',4),(5,'yeonho2010',5),(6,'yeonho2010',6);
/*!40000 ALTER TABLE `bookmarkstbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `expires_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locationstbl`
--

DROP TABLE IF EXISTS `locationstbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locationstbl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locationstbl`
--

LOCK TABLES `locationstbl` WRITE;
/*!40000 ALTER TABLE `locationstbl` DISABLE KEYS */;
INSERT INTO `locationstbl` VALUES (1,'스타벅스 왕십리역9번출구점','서울 성동구 행당동',37.5612,127.0375,'카페'),(2,'스타벅스 엔터식스점','서울 성동구 성수동',37.5618,127.0339,'카페'),(3,'스타벅스 한양대점','서울 성동구 왕십리로',37.5553,127.0436,'카페'),(4,'맛있는 국밥집','서울 성동구 행당동',37.5605,127.036,'음식점'),(5,'인생 칼국수','서울 성동구 사근동',37.558,127.0425,'음식점'),(6,'힙한 팝업 마켓','서울 성동구 성수동',37.5625,127.032,'팝업스토어'),(7,'스타벅스 상왕십리역점','서울 중구 하왕십리',37.5645,127.0294,'카페');
/*!40000 ALTER TABLE `locationstbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membertbl`
--

DROP TABLE IF EXISTS `membertbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `membertbl` (
  `memberid` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `school` varchar(50) DEFAULT NULL,
  `major` varchar(50) DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `gpa` double DEFAULT '0',
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membertbl`
--

LOCK TABLES `membertbl` WRITE;
/*!40000 ALTER TABLE `membertbl` DISABLE KEYS */;
INSERT INTO `membertbl` VALUES ('beitetv','dldusgh2010!','맴버','beitetv@gmail.com','동양미래대','컴소과','99999999','user',1,0),('dd','zxcasdqwe','하하','bjh00207@dongyang.ac.kr','동양미래대','컴소과','99999999','user',1,0),('dongyang','dongyang','총괄관리자','dongyang@naver.com','동양미래대','컴소과','99999999','admin',1,4.5);
/*!40000 ALTER TABLE `membertbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receiver_id` varchar(50) NOT NULL,
  `sender_id` varchar(50) NOT NULL,
  `product_id` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `sender_id` (`sender_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`receiver_id`) REFERENCES `membertbl` (`memberid`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `membertbl` (`memberid`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `productstbl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `image_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `productstbl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productstbl`
--

DROP TABLE IF EXISTS `productstbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productstbl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` bigint DEFAULT '0',
  `addr` varchar(255) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `description` text,
  `member_id` varchar(50) DEFAULT NULL,
  `views` int DEFAULT '0',
  `status` varchar(20) DEFAULT 'SALE',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_product_member` (`member_id`),
  CONSTRAINT `fk_product_member` FOREIGN KEY (`member_id`) REFERENCES `membertbl` (`memberid`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productstbl`
--

LOCK TABLES `productstbl` WRITE;
/*!40000 ALTER TABLE `productstbl` DISABLE KEYS */;
INSERT INTO `productstbl` VALUES (1,'아이패드 성수동 직거래',550000,'성수동1가',37.545,127.048,'전자기기','img/products/ipad_seongsu.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(2,'닌텐도 스위치 (왕십리역)',230000,'행당동',37.561,127.037,'전자기기','img/products/switch_wangsimni.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(3,'로지텍 G Pro 무선 마우스',70000,'성수동2가',37.541,127.056,'전자기기','img/products/logitech_gpro.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(4,'삼성 32인치 모니터',190000,'행당동',37.558,127.039,'전자기기','img/products/samsung_monitor_32.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(5,'애플워치 SE 2 (옥수동)',250000,'옥수동',37.541,127.018,'전자기기','img/products/apple_watch_se2.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(6,'한양대 공대 전공책 5권',45000,'사근동',37.558,127.044,'전공책','img/products/hanyang_books.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(7,'경영학 교재 (거의 새책)',20000,'왕십리',37.562,127.035,'전공책','img/products/biz_books.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(8,'토익, 텝스 수험서 일괄',30000,'금호동',37.548,127.025,'전공책','img/products/toeic_books.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(9,'나이키 덩크 로우 (265)',80000,'성수동',37.543,127.051,'의류/신발','img/products/nike_dunk.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(10,'아더에러 후드티 (Ader Error)',110000,'성수동',37.54,127.058,'의류/신발','img/products/ader_hoodie.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(11,'젠틀몬스터 선글라스 (성수 쇼룸)',150000,'성수동1가',37.546,127.047,'의류/신발','img/products/gentle_monster.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(12,'무신사 스탠다드 슬랙스',15000,'행당동',37.559,127.041,'의류/신발','img/products/musinsa_slacks.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(13,'이케아 2단 선반 (화이트)',10000,'마장동',37.566,127.041,'가구/인테리어','img/products/ikea_shelf.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(14,'마켓비 스탠드 조명',25000,'옥수동',37.54,127.02,'가구/인테리어','img/products/marketb_lamp.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(15,'1인용 암체어 (금호동)',50000,'금호동',37.549,127.023,'가구/인테리어','img/products/armchair_geumho.jpg',NULL,'yeonho2010',0,'SALE','2025-12-13 06:22:50'),(16,'아이패드 에어5 스페이스그레이 64GB S급',720000,'역삼동',37.5005,127.0364,'전자기기','img/products/ipad_seongsu.jpg','기스 하나 없는 S급입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(17,'아이패드 에어5 블루 64GB 풀박스',750000,'청담동',37.5241,127.0421,'전자기기','img/products/ipad_seongsu.jpg','충전기 포함 풀박스입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(18,'아이패드 에어5 핑크 256GB 미개봉',980000,'삼성동',37.5123,127.0589,'전자기기','img/products/ipad_seongsu.jpg','선물받았는데 안써서 팝니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(19,'아이패드 에어5 스타라이트 급처',680000,'논현동',37.5111,127.0312,'전자기기','img/products/ipad_seongsu.jpg','빠르게 쿨거하실 분만.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(20,'아이패드 에어5 퍼플 상태 좋음',710000,'대치동',37.4932,127.0567,'전자기기','img/products/ipad_seongsu.jpg','필름 붙여서 사용했습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(21,'아이패드 에어5 셀룰러 64GB',820000,'신사동',37.5236,127.0235,'전자기기','img/products/ipad_seongsu.jpg','셀룰러 모델입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(22,'아이패드 에어5 스그 단순개봉',740000,'압구정동',37.5294,127.0298,'전자기기','img/products/ipad_seongsu.jpg','확인차 개봉만 했습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(23,'아이패드 에어5 64기가 와이파이',690000,'도곡동',37.4876,127.0472,'전자기기','img/products/ipad_seongsu.jpg','직거래 선호합니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(24,'아이패드 에어5 블루 펜슬 포함',850000,'개포동',37.4802,127.0665,'전자기기','img/products/ipad_seongsu.jpg','애플펜슬 2세대 같이 드려요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(25,'아이패드 에어5 A급 팝니다',700000,'일원동',37.4833,127.0851,'전자기기','img/products/ipad_seongsu.jpg','생활 기스 약간 있습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(26,'아이패드 에어5 급매',650000,'수서동',37.4874,127.1016,'전자기기','img/products/ipad_seongsu.jpg','네고 사절입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(27,'아이패드 에어5 + 매직키보드',1100000,'잠실동',37.5122,127.0843,'전자기기','img/products/ipad_seongsu.jpg','키보드 세트입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(28,'아이패드 에어5 256GB 스그',950000,'신천동',37.5195,127.1012,'전자기기','img/products/ipad_seongsu.jpg','용량 넉넉합니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(29,'아이패드 에어5 핑크 찍힘 있음',620000,'방이동',37.5131,127.1234,'전자기기','img/products/ipad_seongsu.jpg','모서리 찍힘 감안해서 싸게 팝니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(30,'아이패드 에어5 스타라이트 S급',730000,'오금동',37.5054,127.1356,'전자기기','img/products/ipad_seongsu.jpg','배터리 효율 98%','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(31,'아이패드 프로 11인치 4세대 128GB',1050000,'송파동',37.5042,127.1098,'전자기기','img/products/ipad_seongsu.jpg','M2 칩셋입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(32,'아이패드 프로 12.9 6세대 256GB',1550000,'석촌동',37.5032,127.1034,'전자기기','img/products/ipad_seongsu.jpg','화면 크고 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(33,'아이패드 프로 11 3세대 M1',850000,'가락동',37.4951,127.1231,'전자기기','img/products/ipad_seongsu.jpg','가성비 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(34,'아이패드 프로 12.9 5세대 미니LED',1150000,'문정동',37.4843,127.1222,'전자기기','img/products/ipad_seongsu.jpg','화질 짱입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(35,'아이패드 프로 11 4세대 셀룰러',1200000,'장지동',37.4785,127.1345,'전자기기','img/products/ipad_seongsu.jpg','데이터 함께쓰기 가능.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(36,'아이패드 프로 11 2세대 (구형)',600000,'풍납동',37.5332,127.1154,'전자기기','img/products/ipad_seongsu.jpg','유튜브 머신으로 썼습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(37,'아이패드 프로 12.9 4세대',750000,'성내동',37.5311,127.1298,'전자기기','img/products/ipad_seongsu.jpg','화면 큽니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(38,'아이패드 프로 M2 11인치 실버',1080000,'둔촌동',37.5278,127.1456,'전자기기','img/products/ipad_seongsu.jpg','보증 남았습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(39,'아이패드 프로 M1 12.9 1TB',1600000,'천호동',37.5421,127.1254,'전자기기','img/products/ipad_seongsu.jpg','램 16기가 모델.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(40,'아이패드 프로 11 3세대 급처',820000,'암사동',37.5532,127.1276,'전자기기','img/products/ipad_seongsu.jpg','박스 없어서 싸게 팜.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(41,'아이패드 프로 11인치 256기가',1150000,'명일동',37.5511,127.1432,'전자기기','img/products/ipad_seongsu.jpg','용량 넉넉.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(42,'아이패드 프로 12.9 6세대 풀세트',1800000,'고덕동',37.5555,127.1543,'전자기기','img/products/ipad_seongsu.jpg','키보드, 펜슬 다 드림.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(43,'아이패드 프로 11 4세대 스그',1030000,'상일동',37.5502,127.1654,'전자기기','img/products/ipad_seongsu.jpg','상태 최상.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(44,'아이패드 프로 M1 11인치',870000,'길동',37.5389,127.1401,'전자기기','img/products/ipad_seongsu.jpg','전투형 아님.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(45,'아이패드 프로 12.9 5세대 128GB',1100000,'강일동',37.5654,127.1723,'전자기기','img/products/ipad_seongsu.jpg','화질 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(46,'아이패드 미니6 퍼플 64GB',580000,'서초동',37.4877,127.0174,'전자기기','img/products/ipad_seongsu.jpg','한손에 쏙 들어옵니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(47,'아이패드 미니6 스타라이트 256GB',850000,'반포동',37.5034,127.0012,'전자기기','img/products/ipad_seongsu.jpg','고용량 모델.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(48,'아이패드 미니6 핑크 S급',600000,'방배동',37.4812,126.9923,'전자기기','img/products/ipad_seongsu.jpg','색상 예뻐요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(49,'아이패드 미니6 스페이스그레이 64',570000,'양재동',37.4821,127.0345,'전자기기','img/products/ipad_seongsu.jpg','게임용으로 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(50,'아이패드 미니6 셀룰러 64GB',720000,'우면동',37.4654,127.0234,'전자기기','img/products/ipad_seongsu.jpg','네비용으로 썼습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(51,'아이패드 미니6 젤리스크롤 양호',590000,'원지동',37.4456,127.0543,'전자기기','img/products/ipad_seongsu.jpg','뽑기 잘했습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(52,'아이패드 미니6 펜슬포함',700000,'내곡동',37.4567,127.0678,'전자기기','img/products/ipad_seongsu.jpg','펜슬 같이 드려요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(53,'아이패드 미니6 64기가 급처',550000,'염곡동',37.4623,127.0489,'전자기기','img/products/ipad_seongsu.jpg','싸게 가져가세요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(54,'아이패드 미니6 퍼플 풀박',610000,'신원동',37.4489,127.0612,'전자기기','img/products/ipad_seongsu.jpg','박스 다 있습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(55,'아이패드 미니6 256GB 셀룰러',980000,'잠원동',37.5123,127.0123,'전자기기','img/products/ipad_seongsu.jpg','끝판왕 옵션.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(56,'아이패드 9세대 64GB 스그',320000,'흑석동',37.5089,126.9634,'전자기기','img/products/ipad_seongsu.jpg','가성비 최고.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(57,'아이패드 9세대 실버 64GB',330000,'노량진동',37.5134,126.9456,'전자기기','img/products/ipad_seongsu.jpg','인강용 추천.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(58,'아이패드 9세대 256GB',500000,'상도동',37.5023,126.9489,'전자기기','img/products/ipad_seongsu.jpg','용량 큽니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(59,'아이패드 10세대 핑크 64GB',550000,'본동',37.5112,126.9567,'전자기기','img/products/ipad_seongsu.jpg','디자인 예쁩니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(60,'아이패드 10세대 블루 64GB',540000,'대방동',37.5133,126.9265,'전자기기','img/products/ipad_seongsu.jpg','새것 같습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(61,'아이패드 10세대 실버 미개봉',580000,'신대방동',37.4923,126.9256,'전자기기','img/products/ipad_seongsu.jpg','미개봉 새상품.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(62,'아이패드 9세대 펜슬 포함',400000,'동작동',37.5012,126.9789,'전자기기','img/products/ipad_seongsu.jpg','짭슬펜슬 드림.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(63,'아이패드 9세대 찍힘 다수',250000,'사당동',37.4834,126.9812,'전자기기','img/products/ipad_seongsu.jpg','막 쓰실 분.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(64,'아이패드 10세대 옐로우',560000,'여의도동',37.5211,126.9243,'전자기기','img/products/ipad_seongsu.jpg','병아리 색상.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(65,'아이패드 9세대 와이파이 64',310000,'당산동',37.5321,126.9023,'전자기기','img/products/ipad_seongsu.jpg','배터리 95%.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(66,'아이패드 에어4 스카이블루 64GB',500000,'문래동',37.5189,126.8956,'전자기기','img/products/ipad_seongsu.jpg','에어4 여전히 현역입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(67,'아이패드 에어4 그린 256GB',650000,'양평동',37.5278,126.8867,'전자기기','img/products/ipad_seongsu.jpg','쌈무그린.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(68,'아이패드 에어3 (구형) 64GB',250000,'신길동',37.5056,126.9123,'전자기기','img/products/ipad_seongsu.jpg','유튜브용.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(69,'아이패드 8세대 32GB',200000,'대림동',37.4945,126.8989,'전자기기','img/products/ipad_seongsu.jpg','싸게 팝니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(70,'아이패드 7세대 32GB',180000,'도림동',37.5089,126.9034,'전자기기','img/products/ipad_seongsu.jpg','액정 기스 있음.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(71,'아이패드 프로 10.5 (구형 프로)',300000,'영등포동',37.5156,126.9078,'전자기기','img/products/ipad_seongsu.jpg','화이트스팟 약간 있음.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(72,'아이패드 미니5 64GB',350000,'신도림동',37.5089,126.8823,'전자기기','img/products/ipad_seongsu.jpg','미니5 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(73,'아이패드 에어5 스그 64 단순개봉',730000,'구로동',37.4956,126.8878,'전자기기','img/products/ipad_seongsu.jpg','단순 변심.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(74,'아이패드 프로 11 3세대 128GB',840000,'가리봉동',37.4823,126.889,'전자기기','img/products/ipad_seongsu.jpg','상태 굿.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(75,'아이패드 9세대 64기가 미개봉',350000,'고척동',37.5012,126.8654,'전자기기','img/products/ipad_seongsu.jpg','선물용으로 샀다가 팝니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(76,'아이패드 10세대 256GB 블루',700000,'개봉동',37.4945,126.8543,'전자기기','img/products/ipad_seongsu.jpg','용량 큰거 필요하신 분.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(77,'아이패드 에어5 64GB 퍼플',715000,'오류동',37.4934,126.8432,'전자기기','img/products/ipad_seongsu.jpg','풀박스.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(78,'아이패드 프로 12.9 5세대 256',1250000,'궁동',37.5023,126.8321,'전자기기','img/products/ipad_seongsu.jpg','영상 편집용.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(79,'아이패드 미니6 64GB 핑크',575000,'온수동',37.4921,126.8234,'전자기기','img/products/ipad_seongsu.jpg','예뻐요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(80,'아이패드 에어4 64GB 로즈골드',480000,'천왕동',37.4812,126.8412,'전자기기','img/products/ipad_seongsu.jpg','색감 깡패.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(81,'아이패드 9세대 64GB 실버',325000,'항동',37.4789,126.8212,'전자기기','img/products/ipad_seongsu.jpg','기본형.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(82,'아이패드 프로 11 1세대',500000,'신정동',37.5234,126.8567,'전자기기','img/products/ipad_seongsu.jpg','아직 쓸만합니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(83,'아이패드 에어5 256GB 블루',940000,'목동',37.5321,126.8754,'전자기기','img/products/ipad_seongsu.jpg','고용량 에어.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(84,'아이패드 프로 11 4세대 128',1020000,'신월동',37.5212,126.8345,'전자기기','img/products/ipad_seongsu.jpg','신형 프로.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(85,'아이패드 10세대 64GB 옐로',530000,'가양동',37.5612,126.8543,'전자기기','img/products/ipad_seongsu.jpg','색상 확인하세요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(86,'아이패드 미니6 64GB 스타라이트',585000,'염창동',37.5543,126.8678,'전자기기','img/products/ipad_seongsu.jpg','깔끔합니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(87,'아이패드 에어5 64GB 스그 A급',690000,'등촌동',37.5521,126.849,'전자기기','img/products/ipad_seongsu.jpg','뒷판 미세 기스.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(88,'아이패드 프로 12.9 6세대 128',1450000,'화곡동',37.5412,126.8456,'전자기기','img/products/ipad_seongsu.jpg','고사양.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(89,'아이패드 9세대 64GB 스그 풀박',340000,'마곡동',37.5678,126.829,'전자기기','img/products/ipad_seongsu.jpg','풀구성.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(90,'아이패드 에어4 256GB 스카이블루',630000,'내발산동',37.5534,126.8321,'전자기기','img/products/ipad_seongsu.jpg','용량 큼.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(91,'아이패드 10세대 핑크 단순개봉',570000,'외발산동',37.5423,126.8212,'전자기기','img/products/ipad_seongsu.jpg','새거랑 다름없음.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(92,'아이패드 프로 11 2세대 128',620000,'공항동',37.5612,126.8123,'전자기기','img/products/ipad_seongsu.jpg','가성비 프로.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(93,'아이패드 미니6 256GB 퍼플',830000,'방화동',37.5712,126.8145,'전자기기','img/products/ipad_seongsu.jpg','용량 걱정 없음.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(94,'아이패드 에어5 64GB 블루 급처',670000,'개화동',37.5812,126.8012,'전자기기','img/products/ipad_seongsu.jpg','급전 필요.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(95,'아이패드 프로 12.9 3세대 (구형)',650000,'과해동',37.5555,126.7989,'전자기기','img/products/ipad_seongsu.jpg','화면 큰거 싼맛에.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(96,'아이패드 9세대 64GB 상태 쏘쏘',280000,'오곡동',37.5444,126.7878,'전자기기','img/products/ipad_seongsu.jpg','찍힘 있어서 싸게.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(97,'아이패드 에어3 256GB',320000,'오쇠동',37.5333,126.7999,'전자기기','img/products/ipad_seongsu.jpg','용량 큰 에어3.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(98,'아이패드 7세대 128GB',230000,'망원동',37.5567,126.9012,'전자기기','img/products/ipad_seongsu.jpg','인강 머신.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(99,'아이패드 프로 10.5 256GB',350000,'성산동',37.5678,126.9123,'전자기기','img/products/ipad_seongsu.jpg','120hz 지원.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(100,'아이패드 미니5 256GB',420000,'상암동',37.5789,126.8965,'전자기기','img/products/ipad_seongsu.jpg','미니5 고용량.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(101,'아이패드 에어5 64GB 핑크 A급',705000,'연남동',37.5634,126.9234,'전자기기','img/products/ipad_seongsu.jpg','상태 좋습니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(102,'아이패드 프로 11 3세대 256',920000,'서교동',37.5543,126.9212,'전자기기','img/products/ipad_seongsu.jpg','홍대 직거래.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(103,'아이패드 9세대 64GB 와이파이',315000,'동교동',37.5567,126.9256,'전자기기','img/products/ipad_seongsu.jpg','박스 있음.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(104,'아이패드 10세대 64GB 실버',545000,'합정동',37.5489,126.9134,'전자기기','img/products/ipad_seongsu.jpg','거의 새거.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(105,'아이패드 에어4 64GB 그린',490000,'상수동',37.5478,126.9223,'전자기기','img/products/ipad_seongsu.jpg','전원 버튼 함몰(지문인식 됨).','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(106,'아이패드 프로 12.9 5세대 512GB',1350000,'창전동',37.549,126.9312,'전자기기','img/products/ipad_seongsu.jpg','용량 깡패.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(107,'아이패드 미니6 64GB 스타라이트 A',590000,'구수동',37.5456,126.9367,'전자기기','img/products/ipad_seongsu.jpg','생활기스 조금.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(108,'아이패드 에어5 64GB 스그 미개봉',760000,'신수동',37.5467,126.9389,'전자기기','img/products/ipad_seongsu.jpg','미개봉입니다.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(109,'아이패드 프로 11 4세대 256',1120000,'현석동',37.5432,126.9401,'전자기기','img/products/ipad_seongsu.jpg','M2 프로.','yeonho2010',0,'SALE','2025-12-13 06:22:50'),(110,'아이패드 9세대 64GB 스그',310000,'토정동',37.5412,126.9423,'전자기기','img/products/ipad_seongsu.jpg','가성비.','dongyang',0,'SALE','2025-12-13 06:22:50'),(111,'1인용 리클라이너 소파',80000,'고척동',37.4985,126.863,'가구/인테리어','img/products/가구,인테리어/1인용 리클라이너 소파.jpg','편안한 휴식을 위한 1인용 소파입니다.','yeonho2010',15,'SALE','2025-12-13 05:22:50'),(112,'단스탠드 무드등',15000,'구로동',37.4965,126.883,'가구/인테리어','img/products/가구,인테리어/단스탠드 무드등.PNG','감성적인 분위기 연출에 좋습니다.','dongyang',8,'SALE','2025-12-13 03:22:50'),(113,'마켓비 철제 서랍장 6단',35000,'신도림동',37.5085,126.892,'가구/인테리어','img/products/가구,인테리어/마켓비 철제 서랍장 6단.jpg','수납 공간 넉넉합니다.','yeonho2010',22,'SALE','2025-12-13 01:22:50'),(114,'빈티지 러그 카페트',25000,'개봉동',37.4915,126.853,'가구/인테리어','img/products/가구,인테리어/빈티지 러그 카페트.PNG','세탁 완료했습니다.','yeonho2010',10,'SALE','2025-12-12 06:22:50'),(115,'시디즈 T50 air 의자',180000,'오류동',37.494,126.844,'가구/인테리어','img/products/가구,인테리어/시디즈 T50 air 의자.jpg','허리가 편한 의자입니다.','yeonho2010',45,'SALE','2025-12-11 06:22:50'),(116,'오늘의집 3단 책장',20000,'항동',37.479,126.823,'가구/인테리어','img/products/가구,인테리어/오늘의집 3단 책장.PNG','책 많이 들어갑니다.','dongyang',5,'SALE','2025-12-11 06:22:50'),(117,'원목 2단 행거',18000,'천왕동',37.4805,126.8405,'가구/인테리어','img/products/가구,인테리어/원목 2단 행거.PNG','튼튼하고 디자인 예쁩니다.','yeonho2010',12,'SOLD','2025-12-10 06:22:50'),(118,'이케아 책상',30000,'가리봉동',37.4815,126.891,'가구/인테리어','img/products/가구,인테리어/이케아 책상.PNG','상판 깨끗합니다.','yeonho2010',18,'SALE','2025-12-09 06:22:50'),(119,'전신 거울 (화이트 프레임)',15000,'궁동',37.5015,126.833,'가구/인테리어','img/products/가구,인테리어/전신 거울 (화이트 프레임).PNG','자취방 필수템입니다.','yeonho2010',7,'SALE','2025-12-08 06:22:50'),(120,'접이식 매트리스 (싱글)',40000,'목동',37.531,126.872,'가구/인테리어','img/products/가구,인테리어/접이식 매트리스 (싱글).jpg','손님용으로 몇 번 안 썼습니다.','dongyang',25,'SALE','2025-12-06 06:22:50'),(121,'다이슨 에어랩 컴플리트 롱',550000,'고척동',37.499,126.865,'뷰티/미용','img/products/뷰티,미용/다이슨 에어랩 컴플리트 롱.jpg','풀박스 구성입니다.','yeonho2010',50,'SALE','2025-12-13 05:22:50'),(122,'다이슨 에어랩 컴플리트 롱 (2)',540000,'고척동',37.499,126.865,'뷰티/미용','img/products/뷰티,미용/다이슨 에어랩 컴플리트 롱2.jpg','거의 새것입니다.','yeonho2010',30,'SALE','2025-12-13 04:22:50'),(123,'맥(MAC) 루비우 립스틱',25000,'신도림동',37.508,126.89,'뷰티/미용','img/products/뷰티,미용/맥(MAC) 루비우 립스틱.PNG','1회 발색했습니다.','dongyang',15,'SALE','2025-12-13 02:22:50'),(124,'보다나 봉고데기 36mm 핑크',45000,'개봉동',37.489,126.851,'뷰티/미용','img/products/뷰티,미용/보다나 봉고데기 36mm 핑크.PNG','작동 잘 됩니다.','yeonho2010',20,'SALE','2025-12-12 06:22:50'),(125,'샤넬 넘버5 향수 100ml',180000,'오류동',37.492,126.841,'뷰티/미용','img/products/뷰티,미용/샤넬 넘버5 향수 100ml.PNG','선물받은 미개봉품입니다.','yeonho2010',10,'SALE','2025-12-12 06:22:50'),(126,'설화수 자음 2종 세트',85000,'항동',37.477,126.821,'뷰티/미용','img/products/뷰티,미용/설화수 자음 2종 세트.PNG','부모님 선물용으로 추천.','dongyang',5,'SALE','2025-12-11 06:22:50'),(127,'아베다 우든 패들 브러쉬',20000,'천왕동',37.48,126.842,'뷰티/미용','img/products/뷰티,미용/아베다 우든 패들 브러쉬.PNG','두피 마사지에 좋아요.','yeonho2010',8,'SALE','2025-12-10 06:22:50'),(128,'이솝 핸드크림 (레저렉션)',28000,'가리봉동',37.481,126.888,'뷰티/미용','img/products/뷰티,미용/이솝 핸드크림 (레저렉션).PNG','향이 너무 좋습니다.','yeonho2010',12,'SOLD','2025-12-09 06:22:50'),(129,'입생로랑 틴트 12호',35000,'구로동',37.496,126.886,'뷰티/미용','img/products/뷰티,미용/입생로랑 틴트 12호.PNG','인기 색상입니다.','dongyang',18,'SALE','2025-12-08 06:22:50'),(130,'조말론 디퓨저 (잉글리쉬 페어)',95000,'목동',37.53,126.87,'뷰티/미용','img/products/뷰티,미용/조말론 디퓨저 (잉글리쉬 페어).PNG','집들이 선물로 최고.','yeonho2010',25,'SALE','2025-12-07 06:22:50'),(131,'필립스 전기면도기 9000',160000,'신정동',37.52,126.86,'뷰티/미용','img/products/뷰티,미용/필립스 전기면도기 9000.PNG','세척기 포함 풀세트.','yeonho2010',14,'SALE','2025-12-06 06:22:50'),(132,'3단 빨래 건조대',15000,'오류동',37.491,126.842,'생활용품','img/products/생활용품/3단 빨래 건조대.PNG','튼튼해서 이불도 널 수 있어요.','yeonho2010',8,'SALE','2025-12-13 05:52:50'),(133,'3단 빨래 건조대 (사용감 있음)',10000,'오류동',37.491,126.842,'생활용품','img/products/생활용품/3단 빨래 건조대_2.PNG','저렴하게 가져가세요.','yeonho2010',5,'SALE','2025-12-13 05:52:50'),(134,'규조토 발매트 (그레이)',12000,'신도림동',37.507,126.889,'생활용품','img/products/생활용품/규조토 발매트 (그레이).jpg','물기 흡수 빠릅니다.','yeonho2010',10,'SALE','2025-12-13 04:22:50'),(135,'규조토 발매트 그레이',12000,'신도림동',37.507,126.889,'생활용품','img/products/생활용품/규조토 발매트 그레이.PNG','새상품입니다.','yeonho2010',7,'SALE','2025-12-13 04:22:50'),(136,'극세사 이불',45000,'구로동',37.493,126.884,'생활용품','img/products/생활용품/극세사 이불.PNG','겨울 따뜻하게 보내세요.','dongyang',15,'SALE','2025-12-13 01:22:50'),(137,'극세사 이불 (차콜)',45000,'구로동',37.493,126.884,'생활용품','img/products/생활용품/극세사 이불_2.PNG','세탁 완료했습니다.','dongyang',12,'SALE','2025-12-13 01:22:50'),(138,'다우니 섬유유연제 3개',18000,'개봉동',37.491,126.852,'생활용품','img/products/생활용품/다우니 섬유유연제 3개.PNG','향 오래갑니다.','yeonho2010',20,'SALE','2025-12-12 06:22:50'),(139,'락앤락 밀폐용기 세트',25000,'고척동',37.5,126.864,'생활용품','img/products/생활용품/락앤락 밀폐용기 세트.PNG','유리라 위생적입니다.','yeonho2010',18,'SALE','2025-12-11 06:22:50'),(140,'브리타 정수기 마렐라 XL',32000,'항동',37.476,126.822,'생활용품','img/products/생활용품/브리타 정수기 마렐라 XL.PNG','필터 하나 남은거 드려요.','dongyang',25,'SALE','2025-12-10 06:22:50'),(141,'스타벅스 텀블러 (블랙)',28000,'천왕동',37.482,126.843,'생활용품','img/products/생활용품/스타벅스 텀블러 (블랙).jpg','선물받은 건데 안써서 팝니다.','yeonho2010',30,'SALE','2025-12-09 06:22:50'),(142,'스탠리 텀블러 591',35000,'가리봉동',37.483,126.89,'생활용품','img/products/생활용품/스탠리 텀블러 591.PNG','얼음 진짜 오래가요.','yeonho2010',40,'SALE','2025-12-08 06:22:50'),(143,'스탠리 텀블러 591 (새상품)',38000,'가리봉동',37.483,126.89,'생활용품','img/products/생활용품/스탠리 텀블러 591_2.PNG','박스째 보관 중.','yeonho2010',15,'SALE','2025-12-08 06:22:50'),(144,'암막 커튼 그레이 (2장)',30000,'궁동',37.503,126.831,'생활용품','img/products/생활용품/암막 커튼 그레이 (2장).PNG','빛 차단 확실합니다.','yeonho2010',11,'SOLD','2025-12-07 06:22:50'),(145,'코스트코 커클랜드 휴지 30롤',22000,'수궁동',37.501,126.836,'생활용품','img/products/생활용품/코스트코 커클랜드 휴지 30롤.PNG','가성비 최고.','dongyang',9,'SALE','2025-12-06 06:22:50'),(146,'나이키 530',85000,'신정동',37.522,126.858,'의류/신발','img/products/의류,신발/나이키 530.PNG','발이 편해요. 240 사이즈.','yeonho2010',25,'SALE','2025-12-13 05:22:50'),(147,'나이키 덩크 로우 범고래 270',120000,'목동',37.53,126.87,'의류/신발','img/products/의류,신발/나이키 덩크 로우 범고래 270.jpg','국민 신발, 상태 좋습니다.','yeonho2010',45,'SALE','2025-12-13 03:22:50'),(148,'노스페이스 눕시 패딩',250000,'고척동',37.4985,126.863,'의류/신발','img/products/의류,신발/노스페이스 눕시.PNG','올 겨울 따뜻하게.','dongyang',60,'SALE','2025-12-13 00:22:50'),(149,'닥터마틴 1461 모노',110000,'구로동',37.4965,126.883,'의류/신발','img/products/의류,신발/닥터마틴 1461 모노.PNG','주름 조금 있습니다.','yeonho2010',18,'SALE','2025-12-12 06:22:50'),(150,'리바이스 501 청바지 32사이즈',45000,'신도림동',37.5085,126.892,'의류/신발','img/products/의류,신발/리바이스 501 청바지 32사이즈.PNG','핏이 예쁩니다.','yeonho2010',12,'SALE','2025-12-11 06:22:50'),(151,'리바이스 501 청바지 (진청)',45000,'신도림동',37.5085,126.892,'의류/신발','img/products/의류,신발/리바이스 501 청바지 32사이즈2.PNG','물빠짐 없습니다.','yeonho2010',10,'SALE','2025-12-11 06:22:50'),(152,'스투시 반팔',40000,'개봉동',37.4915,126.853,'의류/신발','img/products/의류,신발/스투시 반팔.PNG','L 사이즈입니다.','yeonho2010',22,'SALE','2025-12-10 06:22:50'),(153,'아디다스 트랙탑',60000,'오류동',37.494,126.844,'의류/신발','img/products/의류,신발/아디다스 트랙탑.PNG','빈티지 스타일.','yeonho2010',15,'SALE','2025-12-09 06:22:50'),(154,'유니클로 후리스 자켓',15000,'항동',37.479,126.823,'의류/신발','img/products/의류,신발/유니클로 후리스 자켓.PNG','실내용으로 입기 좋아요.','dongyang',8,'SALE','2025-12-08 06:22:50'),(155,'유니클로 후리스 자켓 (베이지)',15000,'항동',37.479,126.823,'의류/신발','img/products/의류,신발/유니클로 후리스 자켓2.PNG','따뜻합니다.','dongyang',7,'SALE','2025-12-08 06:22:50'),(156,'자라(ZARA) 오버핏 코트',90000,'천왕동',37.4805,126.8405,'의류/신발','img/products/의류,신발/자라(ZARA) 오버핏 코트.PNG','결혼식 갈 때 딱입니다.','yeonho2010',20,'SALE','2025-12-07 06:22:50'),(157,'칼하트 WIP 후드티 그레이',75000,'가리봉동',37.4815,126.891,'의류/신발','img/products/의류,신발/칼하트 WIP 후드티 그레이.PNG','기모 짱짱합니다.','yeonho2010',30,'SALE','2025-12-06 06:22:50'),(158,'칼하트 WIP 후드티 (M사이즈)',75000,'가리봉동',37.4815,126.891,'의류/신발','img/products/의류,신발/칼하트 WIP 후드티 그레이2.PNG','사이즈 미스로 팝니다.','yeonho2010',18,'SALE','2025-12-06 06:22:50'),(159,'컨버스 척테일러 1970s 블랙',55000,'궁동',37.5015,126.833,'의류/신발','img/products/의류,신발/컨버스 척테일러 1970s 블랙.PNG','어디에나 잘 어울려요.','yeonho2010',35,'SOLD','2025-12-06 06:22:50'),(160,'컨버스 척테일러 1970s 블랙 (260)',50000,'궁동',37.5015,126.833,'의류/신발','img/products/의류,신발/컨버스 척테일러 1970s 블랙2.PNG','사용감 조금 있습니다.','yeonho2010',20,'SALE','2025-12-06 06:22:50'),(161,'C언어 본색',15000,'고척동',37.4992,126.864,'전공책','img/products/전공책/C언어본색.jpg','프로그래밍 기초.','yeonho2010',5,'SALE','2025-12-13 05:52:50'),(162,'데이터베이스 개론',18000,'신도림동',37.5085,126.8915,'전공책','img/products/전공책/데이터베이스개론.PNG','밑줄 필기 조금 있음.','dongyang',12,'SALE','2025-12-13 04:22:50'),(163,'데이터베이스 개론 (개정판)',19000,'신도림동',37.5085,126.8915,'전공책','img/products/전공책/데이터베이스개론2.PNG','상태 깨끗합니다.','dongyang',8,'SALE','2025-12-13 04:22:50'),(164,'맨큐의 경제학',25000,'구로동',37.495,126.8845,'전공책','img/products/전공책/맨큐의 경제학.jpg','경제학 입문서.','yeonho2010',10,'SALE','2025-12-13 02:22:50'),(165,'쉽게 배우는 자바 프로그래밍',20000,'개봉동',37.4895,126.8525,'전공책','img/products/전공책/쉽게 배우는 자바프로그래밍.PNG','자바 필수 교재.','yeonho2010',25,'SALE','2025-12-12 06:22:50'),(166,'알고리즘 문제해결 전략',30000,'오류동',37.4935,126.8405,'전공책','img/products/전공책/알고리즘 문제해결.jpg','코딩테스트 준비용.','yeonho2010',30,'SALE','2025-12-11 06:22:50'),(167,'알고리즘 문제해결 전략 2',30000,'오류동',37.4935,126.8405,'전공책','img/products/전공책/알고리즘 문제해결2.webp','2권입니다.','yeonho2010',15,'SALE','2025-12-11 06:22:50'),(168,'운영체제 (공룡책) 10판',35000,'천왕동',37.4805,126.8415,'전공책','img/products/전공책/운영체제 (공룡책) 10판.jpg','전공 필수입니다.','dongyang',20,'SALE','2025-12-10 06:22:50'),(169,'이산수학 Express',17000,'항동',37.4765,126.8215,'전공책','img/products/전공책/이산수학.PNG','연습문제 풀이 포함.','yeonho2010',8,'SALE','2025-12-09 06:22:50'),(170,'컴퓨터구조론',22000,'수궁동',37.5005,126.8355,'전공책','img/products/전공책/컴퓨터구조론.jpg','거의 새책입니다.','yeonho2010',11,'SALE','2025-12-08 06:22:50'),(171,'토익 기출문제집',12000,'신정동',37.521,126.859,'전공책','img/products/전공책/토익기출.webp','앞부분만 조금 풀었어요.','yeonho2010',15,'SALE','2025-12-07 06:22:50'),(172,'파이썬 딥러닝',25000,'화곡동',37.5405,126.8445,'전공책','img/products/전공책/파이썬 딥러닝.jpg','AI 공부하실 분.','dongyang',22,'SALE','2025-12-06 06:22:50'),(173,'갤럭시 S23 울트라 크림',950000,'고척동',37.498,126.862,'전자기기','img/products/전자기기/갤럭시 S23 울트라 크림.jpg','카메라 성능 최고입니다. 기스 없음.','yeonho2010',55,'SALE','2025-12-13 05:22:50'),(174,'갤럭시 S23',750000,'구로동',37.4955,126.887,'전자기기','img/products/전자기기/갤럭시 S23.PNG','한 손에 들어오는 사이즈.','yeonho2010',30,'SALE','2025-12-13 04:22:50'),(175,'갤럭시탭 S9',850000,'신도림동',37.509,126.891,'전자기기','img/products/전자기기/갤럭시탭s9.PNG','영상 시청용으로 최고.','dongyang',25,'SALE','2025-12-13 03:22:50'),(176,'갤럭시탭 S9 울트라',1100000,'신도림동',37.509,126.891,'전자기기','img/products/전자기기/갤럭시탭s92.PNG','화면 진짜 큽니다.','dongyang',15,'SALE','2025-12-13 03:22:50'),(177,'닌텐도 스위치2',350000,'개봉동',37.49,126.85,'전자기기','img/products/전자기기/닌텐도 스위치2.jpg','박스 풀구성입니다.','yeonho2010',40,'SALE','2025-12-12 06:22:50'),(178,'닌텐도 스위치3',320000,'개봉동',37.49,126.85,'전자기기','img/products/전자기기/닌텐도 스위치3.jpg','조이콘 쏠림 없음.','yeonho2010',20,'SALE','2025-12-12 06:22:50'),(179,'닌텐도 스위치 OLED',380000,'오류동',37.493,126.84,'전자기기','img/products/전자기기/닌텐도 스위칯.jpg','화질 좋은 OLED 모델.','yeonho2010',50,'SALE','2025-12-11 06:22:50'),(180,'로지텍 마우스',85000,'항동',37.478,126.82,'전자기기','img/products/전자기기/로지텍.PNG','손목 편한 버티컬 마우스.','dongyang',12,'SALE','2025-12-10 06:22:50'),(181,'로지텍 마우스 (MX Master)',90000,'항동',37.478,126.82,'전자기기','img/products/전자기기/로지텍2.PNG','업무 효율 올라갑니다.','dongyang',10,'SALE','2025-12-10 06:22:50'),(182,'맥북 프로 M1',1300000,'천왕동',37.481,126.841,'전자기기','img/products/전자기기/맥북프로M1.PNG','개발자 추천 노트북.','yeonho2010',60,'SALE','2025-12-09 06:22:50'),(183,'맥북 프로 M1 (스페이스그레이)',1350000,'천왕동',37.481,126.841,'전자기기','img/products/전자기기/맥북프로M1_2.PNG','상태 S급입니다.','yeonho2010',35,'SALE','2025-12-09 06:22:50'),(184,'삼성 오디세이 게이밍 모니터 32인치',450000,'궁동',37.502,126.83,'전자기기','img/products/전자기기/삼성 오디세이 게이밍 모니터 32인치.jpg','144Hz 지원.','yeonho2010',22,'SALE','2025-12-08 06:22:50'),(185,'삼성 오디세이 게이밍 모니터',420000,'궁동',37.502,126.83,'전자기기','img/products/전자기기/삼성 오디세이 게이밍 모니터 32인치2.jpg','박스 있습니다.','yeonho2010',15,'SALE','2025-12-08 06:22:50'),(186,'소니 WH-1000XM5',350000,'가리봉동',37.482,126.889,'전자기기','img/products/전자기기/소니 WH-1000XM5.jpg','노이즈 캔슬링 끝판왕.','yeonho2010',45,'SALE','2025-12-07 06:22:50'),(187,'소니 헤드셋',150000,'가리봉동',37.482,126.889,'전자기기','img/products/전자기기/소니 헤드셋.PNG','가성비 좋습니다.','yeonho2010',20,'SALE','2025-12-07 06:22:50'),(188,'스위치 젤다 칩',45000,'수궁동',37.5,126.835,'전자기기','img/products/전자기기/스위치-젤다칩.jpg','야생의 숨결.','dongyang',30,'SOLD','2025-12-06 06:22:50'),(189,'스위치 젤다 칩 (왕눈)',50000,'수궁동',37.5,126.835,'전자기기','img/products/전자기기/스위치-젤다칩2.jpg','왕국의 눈물.','dongyang',35,'SALE','2025-12-06 06:22:50'),(190,'아이패드 미니',550000,'신정동',37.52,126.86,'전자기기','img/products/전자기기/아이패드 미니.PNG','휴대성 갑.','yeonho2010',28,'SALE','2025-12-06 06:22:50'),(191,'아이패드 미니 6세대',600000,'신정동',37.52,126.86,'전자기기','img/products/전자기기/아이패드 미니2.PNG','퍼플 색상입니다.','yeonho2010',22,'SALE','2025-12-06 06:22:50'),(192,'아이패드 에어5 블루',750000,'목동',37.53,126.87,'전자기기','img/products/전자기기/아이패드 에어5 블루.webp','M1 칩 탑재.','yeonho2010',40,'SALE','2025-12-06 06:22:50'),(193,'아이패드 에어5 블루 (급처)',700000,'목동',37.53,126.87,'전자기기','img/products/전자기기/아이패드에어5 블루.jpg','빨리 팔고 싶어요.','yeonho2010',50,'SALE','2025-12-06 06:22:50'),(194,'애플워치',300000,'고척동',37.499,126.865,'전자기기','img/products/전자기기/애플워치.PNG','운동할 때 좋습니다.','dongyang',15,'SALE','2025-11-29 06:22:50'),(195,'애플워치 SE',250000,'고척동',37.499,126.865,'전자기기','img/products/전자기기/애플워치2.PNG','생활 기스 조금.','dongyang',10,'SALE','2025-11-29 06:22:50'),(196,'에어팟 프로 2세대 C타입',230000,'신도림동',37.508,126.89,'전자기기','img/products/전자기기/에어팟 프로 2세대 C타입.jpeg','미개봉 새상품.','yeonho2010',55,'SALE','2025-12-13 03:22:50'),(197,'에어팟 프로 2세대',210000,'신도림동',37.508,126.89,'전자기기','img/products/전자기기/에어팟프로2.PNG','케이스 씌워 썼습니다.','yeonho2010',40,'SALE','2025-12-13 03:22:50'),(198,'엘지그램',1000000,'개봉동',37.489,126.851,'전자기기','img/products/전자기기/엘지그램.PNG','가벼운 노트북.','yeonho2010',30,'SALE','2025-12-12 06:22:50'),(199,'엘지그램 16인치',1100000,'개봉동',37.489,126.851,'전자기기','img/products/전자기기/엘지그램2.PNG','화면 큽니다.','yeonho2010',25,'SALE','2025-12-12 06:22:50'),(200,'엘지그램 17인치',1200000,'개봉동',37.489,126.851,'전자기기','img/products/전자기기/엘지그램3.PNG','고사양 작업 가능.','yeonho2010',20,'SALE','2025-12-12 06:22:50');
/*!40000 ALTER TABLE `productstbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewtbl`
--

DROP TABLE IF EXISTS `reviewtbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewtbl` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reviewer_id` varchar(50) NOT NULL,
  `seller_id` varchar(50) NOT NULL,
  `product_id` int NOT NULL,
  `rating` double NOT NULL,
  `content` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `reviewer_id` (`reviewer_id`),
  KEY `seller_id` (`seller_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `reviewtbl_ibfk_1` FOREIGN KEY (`reviewer_id`) REFERENCES `membertbl` (`memberid`) ON DELETE CASCADE,
  CONSTRAINT `reviewtbl_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `membertbl` (`memberid`) ON DELETE CASCADE,
  CONSTRAINT `reviewtbl_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `productstbl` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewtbl`
--

LOCK TABLES `reviewtbl` WRITE;
/*!40000 ALTER TABLE `reviewtbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviewtbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `safe_zones`
--

DROP TABLE IF EXISTS `safe_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `safe_zones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `safe_zones`
--

LOCK TABLES `safe_zones` WRITE;
/*!40000 ALTER TABLE `safe_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `safe_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_logs`
--

DROP TABLE IF EXISTS `search_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  `search_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_logs`
--

LOCK TABLES `search_logs` WRITE;
/*!40000 ALTER TABLE `search_logs` DISABLE KEYS */;
INSERT INTO `search_logs` VALUES (1,'아이패드','2025-12-13 06:22:50'),(2,'아이패드','2025-12-13 06:22:50'),(3,'아이패드','2025-12-13 06:22:50'),(4,'아이패드','2025-12-13 06:22:50'),(5,'아이패드','2025-12-13 06:22:50'),(6,'전공책','2025-12-13 06:22:50'),(7,'전공책','2025-12-13 06:22:50'),(8,'전공책','2025-12-13 06:22:50'),(9,'에어팟','2025-12-13 06:22:50'),(10,'에어팟','2025-12-13 06:22:50'),(11,'자취방','2025-12-13 06:22:50'),(12,'기숙사','2025-12-13 06:22:50');
/*!40000 ALTER TABLE `search_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-13 15:23:33
