package com.dongyang.dao;

import com.dongyang.dto.ProductDTO;
import com.dongyang.util.JdbcConnectUtil; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	
	/**
	 * productstbl 테이블에서 모든 상품 정보를 가져옵니다.
	 */
	public List<ProductDTO> getAllProducts() {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl;";	

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getLong("price")); 
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));	
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setImageUrl(rs.getString("image_url")); 
				dto.setDescription(rs.getString("description"));
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 정보 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	/**
	 * 새로운 상품 정보를 DB에 삽입하는 메서드
	 */
	public boolean addProduct(ProductDTO pdto) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = "INSERT INTO productstbl (name, price, addr, lat, lng, category, image_url, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";	
		
		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, pdto.getName());
			pstmt.setLong(2, pdto.getPrice());
			pstmt.setString(3, pdto.getAddr());
			pstmt.setDouble(4, pdto.getLat());
			pstmt.setDouble(5, pdto.getLng());
			pstmt.setString(6, pdto.getCategory());
			pstmt.setString(7, pdto.getImageUrl());
			pstmt.setString(8, pdto.getDescription());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("상품 정보 삽입 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, null);
		}
		return result > 0;
	}
	
	//관리자:상품관리
	public boolean deleteProduct(int productId) {
        String sql = "DELETE FROM productstbl WHERE id = ?";
        Connection con = null;
        PreparedStatement pstmt = null;
        int result = 0;

        try {
            con = JdbcConnectUtil.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, productId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JdbcConnectUtil.close(con, pstmt);
        }
        return result > 0;
    }
	

	/**
	 * 찜 목록 조회 (bookmarkstbl과 productstbl JOIN)
	 */
	public List<ProductDTO> getBookMarkByUserId(String userId) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT p.* " +
					 "FROM productstbl p " +
					 "JOIN bookmarkstbl b ON p.id = b.product_id " +
					 "WHERE b.member_id = ?"; 

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("찜 목록(bookmark) 조회 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
	
	/**
	 * 상품 이름(name)으로 상품을 검색하는 메서드 (LIKE 사용)
	 */
	public List<ProductDTO> searchProductsByName(String keyword) {
		List<ProductDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM productstbl WHERE name LIKE ?";

		try {
			con = JdbcConnectUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + keyword + "%"); 
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProductDTO dto = new ProductDTO();
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				dto.setAddr(rs.getString("addr"));
				dto.setLat(rs.getDouble("lat"));
				dto.setLng(rs.getDouble("lng"));
				dto.setCategory(rs.getString("category"));
				dto.setPrice(rs.getLong("price"));
				dto.setImageUrl(rs.getString("image_url"));
				dto.setDescription(rs.getString("description"));
				list.add(dto);
			}
		} catch (SQLException e) {
			System.err.println("상품 검색(searchProductsByName) 중 SQL 오류 발생: " + e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcConnectUtil.close(con, pstmt, rs);
		}
		return list;
	}
}