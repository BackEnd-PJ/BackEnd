package com.dongyang.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class NaverService {
    
    // ⚠️ 발급받은 네이버 API 키를 입력하세요
    private static final String CLIENT_ID = "3ofew1yaG22YcJ9r03xz"; 
    private static final String CLIENT_SECRET = "ozXAEgVXR1";

    public String getNaverPriceString(String keyword) {
        try {
            String text = URLEncoder.encode(keyword, "UTF-8");
            
            // 🌟 [핵심 수정] display=100 으로 변경 (최대 100개 조회)
            // sort=lprice (최저가순 정렬) 또는 sort=sim (정확도순) 중 선택
            // 그래프를 그릴 때는 보통 '최저가순(lprice)'이 깔끔하게 우상향 그래프가 나옵니다.
         // lprice -> asc 로 변경하세요! (asc: 오름차순 = 최저가순)
            String apiURL = "https://openapi.naver.com/v1/search/shop.json?query=" + text + "&display=100&sort=sim";            
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", CLIENT_ID);
            con.setRequestProperty("X-Naver-Client-Secret", CLIENT_SECRET);
            
            // ... (이하 responseCode 체크 및 읽기 로직 동일) ...
            
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode == 200) { 
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            } else {  
                br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
            }
            
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = br.readLine()) != null) {
                response.append(inputLine);
            }
            br.close();
            
            return response.toString();
            
        } catch (Exception e) {
            e.printStackTrace();
            return "{}"; 
        }
    }
}