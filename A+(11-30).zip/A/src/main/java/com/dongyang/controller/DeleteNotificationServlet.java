package com.dongyang.controller;

import java.io.IOException;
import com.dongyang.dao.NotificationDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/deleteNotification.do")
public class DeleteNotificationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 알림 ID 받기
        int id = Integer.parseInt(request.getParameter("id"));
        
        NotificationDAO dao = new NotificationDAO();
        boolean success = dao.deleteNotification(id);
        
        response.setContentType("application/json;charset=UTF-8");
        if (success) {
            response.getWriter().write("{\"status\": \"success\"}");
        } else {
            response.getWriter().write("{\"status\": \"fail\"}");
        }
    }
}