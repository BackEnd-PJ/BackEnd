package com.dongyang.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.dongyang.dao.EmailVerifyDAO;
import com.dongyang.util.EmailUtil;
import com.dongyang.util.RandomCodeUtil;

@WebServlet("/sendCodeAjax.do")
public class SendCodeAjaxServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        response.setContentType("application/json;charset=UTF-8");
        
        // ⭐️ [보안 강화] 백엔드 도메인 검증
        // 이메일이 없거나, 대학 도메인이 아니면 거부
        if (email == null || (!email.endsWith(".ac.kr") && !email.endsWith(".edu"))) {
            response.getWriter().write("{\"status\": \"invalid_domain\"}");
            return; 
        }
        
        try {
            // 1. 인증 코드 생성
            String authCode = RandomCodeUtil.createCode();
            
            // 2. DB에 저장
            EmailVerifyDAO vdao = new EmailVerifyDAO();
            vdao.insertOrUpdateCode(email, authCode);

            // 3. 이메일 전송
            String subject = "[A+ 마켓] 인증 코드입니다.";
            String body = "<html><body>"
                        + "<h2>A+ 마켓 인증 코드</h2>"
                        + "<p>인증 코드: <strong style='font-size: 1.5em; color: #DC2626;'>" + authCode + "</strong></p>"
                        + "<p>이 코드를 입력창에 입력해주세요.</p>"
                        + "</body></html>";
            
            EmailUtil.sendEmail(email, subject, body);

            // 성공 응답
            response.getWriter().write("{\"status\": \"success\"}");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("{\"status\": \"fail\"}");
        }
    }
}