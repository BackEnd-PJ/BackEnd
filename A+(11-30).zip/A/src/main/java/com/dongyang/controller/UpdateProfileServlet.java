package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import com.dongyang.dao.MemberDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/updateProfile.do")
public class UpdateProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        HttpSession session = request.getSession();
        MemberDTO loginUser = (MemberDTO) session.getAttribute("memberId");

        if (loginUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 1. 입력값 받기 (닉네임, 이메일, 새 비밀번호)
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        // ⭐️ [추가] 새 비밀번호 파라미터 수신
        String newPassword = request.getParameter("newPassword");

        // 2. DTO 생성 (수정할 정보 담기)
        MemberDTO updateDto = new MemberDTO();
        updateDto.setMemberid(loginUser.getMemberid());
        updateDto.setName(name);
        updateDto.setEmail(email);
        
        // 기존 세션 정보 유지 (학점, 권한 등 사라지지 않게 주의!)
        updateDto.setPassword(loginUser.getPassword()); // 기본은 기존 비번 유지
        updateDto.setRole(loginUser.getRole());
        updateDto.setVerified(loginUser.isVerified()); 
        
        updateDto.setSchool(loginUser.getSchool());     
        updateDto.setMajor(loginUser.getMajor());       
        updateDto.setStudentId(loginUser.getStudentId()); 
        updateDto.setGpa(loginUser.getGpa()); // ⭐️ [추가] 학점 정보 유지

        MemberDAO dao = new MemberDAO();
        
        // 3-1. 기본 정보(이름, 이메일) 업데이트
        boolean isSuccess = dao.updateMember(updateDto);

        // ⭐️ [추가] 3-2. 새 비밀번호가 입력되었다면 비밀번호 별도 업데이트
        if (newPassword != null && !newPassword.trim().isEmpty()) {
            boolean pwdUpdate = dao.updatePassword(loginUser.getMemberid(), newPassword);
            if(pwdUpdate) {
                // DB 업데이트 성공 시, 세션 객체에도 새 비밀번호 반영
                updateDto.setPassword(newPassword); 
            }
        }

        PrintWriter out = response.getWriter();
        if (isSuccess) {
            // 4. 세션 덮어쓰기 (갱신된 정보로)
            session.setAttribute("memberId", updateDto);
            
            out.println("<script>");
            out.println("alert('프로필이 수정되었습니다.');");
            out.println("location.href='myPage.jsp';");
            out.println("</script>");
        } else {
            out.println("<script>");
            out.println("alert('수정에 실패했습니다.');");
            out.println("history.back();");
            out.println("</script>");
        }
    }
}