package com.dongyang.example1;


import com.dongyang.example1.UserDTO;
import com.dongyang.example1.HttpClientUtil;
import org.json.JSONObject;


public class KakaoServiceDAO {
    private static final String REST_API_KEY = "86491ca04fc14069f8701a512734f839";
    private static final String REDIRECT_URI = "http://localhost:8080/Back_End_Project/kakao/callback";


    public UserDTO getKakaoUser(String code) {
        try {
            // access_token 요청
            String tokenResponse = HttpClientUtil.post(
                    "https://kauth.kakao.com/oauth/token",
                    "grant_type=authorization_code"
                    + "&client_id=" + REST_API_KEY
                    + "&redirect_uri=" + REDIRECT_URI
                    + "&code=" + code
            );

            JSONObject tokenJson = new JSONObject(tokenResponse);
            String accessToken = tokenJson.getString("access_token");

            // 사용자 정보 요청
            String userResponse = HttpClientUtil.getWithAuth(
                    "https://kapi.kakao.com/v2/user/me", accessToken
            );
            JSONObject userJson = new JSONObject(userResponse);

            // DTO 매핑
            UserDTO user = new UserDTO();
            user.setId(userJson.getLong("id"));
            user.setNickname(userJson.getJSONObject("properties").getString("nickname"));
            user.setEmail(userJson.getJSONObject("kakao_account").optString("email", ""));
            return user;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
