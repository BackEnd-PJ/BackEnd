package com.dongyang.example1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession; // HttpSession import

import java.io.IOException;

@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
      
	public void init(ServletConfig config) throws ServletException {		System.out.println("init 메서드 호출!");	}

	// ... (import 및 클래스 정의 부분 유지) ...

	// ... (import 및 클래스 정의 부분 유지) ...

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    //1. 파라미터 받는다
	     String id=request.getParameter("id");
	     String password=request.getParameter("pw");

	     MemberDTO mdto=new MemberDTO();
	     mdto.setMemberid(id);
	     mdto.setPassword(password);
	     
	     MemberDAO mdao=new MemberDAO();
	     boolean result=mdao.loginCheck(mdto);
	     
	     
	     //2. JDBC
	     if(result) {			 
	         // 로그인 성공: 세션 저장 후 index.jsp로 리다이렉트 (성공)
	         HttpSession session = request.getSession();
	         session.setAttribute("loginCheck", "ok"); 
	         session.setAttribute("memberId", id); 
	         response.sendRedirect("index.jsp"); 
	         
	     } else {			
	         // ✅ [수정] 로그인 실패: URL에 파라미터를 추가하여 클라이언트에게 실패 신호를 전달
	         // 기존 요청은 무시하고 새로운 요청으로 리다이렉트합니다.
	         response.sendRedirect("index.jsp?login_error=true"); 
	     }
	}
	// ... (doPost 유지) ...

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}