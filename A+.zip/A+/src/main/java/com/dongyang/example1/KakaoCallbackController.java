package com.dongyang.example1;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;

import com.dongyang.example1.KakaoServiceDAO;
import com.dongyang.example1.UserDTO;

@WebServlet("/kakao/callback")
public class KakaoCallbackController extends HttpServlet {
    private KakaoServiceDAO kakaoService = new KakaoServiceDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("code");
        if (code == null) {
            // code가 없으면 메인으로
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        UserDTO user = kakaoService.getKakaoUser(code);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loginCheck", "ok");
            session.setAttribute("memberId", user.getNickname());
        }

        // ✅ 절대경로로 redirect (에러 해결)
        response.sendRedirect(request.getContextPath() + "/index.jsp");
    }
}
