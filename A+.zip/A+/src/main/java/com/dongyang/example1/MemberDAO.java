package com.dongyang.example1;

import java.sql.*;

public class MemberDAO {
	// ✅ 로그인 체크 메서드 (SELECT)
	public boolean loginCheck(MemberDTO mdto) {
		
			Connection con=null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			boolean loginCheck=false;
			try {
				con=JdbcConnectUtil.getConnection();
				// ⭐️ SQL: ID와 PW가 일치하는 회원을 찾습니다.
				pstmt=con.prepareStatement("select * from membertbl where memberid=? and password=?; ");
				pstmt.setString(1, mdto.getMemberid());
				pstmt.setString(2, mdto.getPassword());				
				rs=pstmt.executeQuery();
				loginCheck=rs.next(); // 결과가 있으면 true (로그인 성공)
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				JdbcConnectUtil.close(con, pstmt, rs);
			}
			return loginCheck;
	}
	
	// ✅ 회원가입 메서드 (INSERT)
	public int registerMember(MemberDTO mdto) {
	    int result = 0;
	    Connection con = null;
	    PreparedStatement pstmt = null;

	    String id = mdto.getMemberid();
	    String pw = mdto.getPassword();
	    String name = mdto.getName();
	    String email = mdto.getEmail();

	    // ⭐️ SQL: 회원 정보를 DB에 삽입합니다.
	    String sql = "INSERT INTO membertbl (memberid, password, name, email) VALUES (?, ?, ?, ?)";
	    
	    try {
	        con = JdbcConnectUtil.getConnection();
	        
	        pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, id); 
	        pstmt.setString(2, pw); 
	        pstmt.setString(3, name); 
	        pstmt.setString(4, email); 
	        
	        result = pstmt.executeUpdate(); // 1이 반환되면 성공

	    } catch (SQLException e) {
	        System.out.println("!! 회원가입 DB 처리 중 에러");
	        e.printStackTrace();
	    } finally {
	    	JdbcConnectUtil.close(con, pstmt); 
	    }
	    
	    return result;
	}
}