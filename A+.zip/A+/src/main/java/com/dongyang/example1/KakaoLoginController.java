package com.dongyang.example1;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/kakao/login")
public class KakaoLoginController extends HttpServlet {
    private static final String REST_API_KEY = "86491ca04fc14069f8701a512734f839";
    private static final String REDIRECT_URI = "http://localhost:8080/Back_End_Project/kakao/callback";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String kakaoAuthUrl = "https://kauth.kakao.com/oauth/authorize?"
                + "client_id=" + REST_API_KEY
                + "&redirect_uri=" + REDIRECT_URI
                + "&response_type=code";

        response.sendRedirect(kakaoAuthUrl);
    }
}

