package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part; // ❗️ 파일 처리를 위한 Part 임포트
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

import com.dongyang.dao.ProductDAO;
import com.dongyang.dto.MemberDTO;
import com.dongyang.dto.ProductDTO;

/**
 * 🌟 중요: @MultipartConfig 어노테이션
 * - 이 서블릿이 'multipart/form-data' (파일 업로드 포함) 요청을
 * 처리할 수 있음을 Tomcat 서버에 알립니다. 이게 없으면 request.getPart()가 작동하지 않습니다.
 */
@WebServlet("/addproduct.do")
@MultipartConfig 
public class AddProductServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// GET 요청은 등록 폼으로 보냅니다. (권장)
		response.sendRedirect("add_product.jsp");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// ⭐️ [신규] 1. 로그인 및 이메일 인증 확인 (보안)
        HttpSession session = request.getSession(false);
        MemberDTO loginUser = null;

        if (session != null) {
            loginUser = (MemberDTO) session.getAttribute("memberId");
        }

        // 1-A: 로그아웃 상태이거나, 1-B: 인증을 안 했으면
        if (loginUser == null || !loginUser.isVerified()) {
            response.sendRedirect("main.jsp"); // 메인으로 리다이렉트
            return;
        }
        
		// 2. 폼 데이터 받기 (텍스트)
		request.setCharacterEncoding("UTF-8"); // 한글 깨짐 방지
		
		String name = request.getParameter("name");
		long price = Long.parseLong(request.getParameter("price"));
		String addr = request.getParameter("addr");
		String category = request.getParameter("category");
		double lat = Double.parseDouble(request.getParameter("lat"));
		double lng = Double.parseDouble(request.getParameter("lng"));
		String description = request.getParameter("description");
		
		// 3. ⭐️ [수정] 다중 파일 처리 로직
        
        // 3-1. 저장 경로 설정
        String uploadPath = getServletContext().getRealPath("") + "images" + File.separator + "products";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // 3-2. 여러 파일 받기
        List<String> savedFileNames = new ArrayList<>(); // DB에 저장할 경로들을 담을 리스트
        Collection<Part> parts = request.getParts(); // 모든 파트(텍스트 포함) 가져오기

        for (Part part : parts) {
            // JSP의 input name="images" 인 것만 처리하고, 실제 파일이 있는 경우만(size > 0)
            if (part.getName().equals("images") && part.getSize() > 0) {
                
                // 파일명 중복 방지 (시간_파일명)
                String originName = part.getSubmittedFileName();
                String fileName = System.currentTimeMillis() + "_" + originName; 
                
                // 서버에 저장 (물리적 경로)
                try {
                    part.write(uploadPath + File.separator + fileName);
                    
                    // DB에 저장할 상대 경로 추가 ("images/products/파일명")
                    savedFileNames.add("images/products/" + fileName);
                    
                } catch (IOException e) {
                    e.printStackTrace();
                    response.sendRedirect("add_product.jsp?error=true");
                    return;
                }
            }
        }

		// 4. ProductDTO 객체 생성 및 데이터 설정
		ProductDTO pdto = new ProductDTO();
		pdto.setName(name);
		pdto.setPrice(price);
		pdto.setAddr(addr);
		pdto.setCategory(category);
		pdto.setLat(lat);
		pdto.setLng(lng);
		pdto.setDescription(description);
		pdto.setMemberId(loginUser.getMemberid());
		
		// ⭐️ [수정] 이미지 리스트 설정
        if (!savedFileNames.isEmpty()) {
            // 첫 번째 이미지를 대표 이미지(썸네일)로 설정 (기존 호환성 유지)
            pdto.setImageUrl(savedFileNames.get(0));
            // 전체 이미지 리스트 저장
            pdto.setImageList(savedFileNames);
        } else {
            // 이미지가 없는 경우 기본값 (혹은 에러 처리)
            pdto.setImageUrl("images/no_image.png"); 
        }
        
		// 5. ProductDAO를 통해 DB에 삽입
		ProductDAO pdao = new ProductDAO();
		boolean success = pdao.addProduct(pdto);
		
		// 6. 결과에 따라 리다이렉트
		if (success) {
			// 성공 시, 새 상품이 추가된 지도 페이지(index.jsp)로 이동
			response.sendRedirect("main.jsp");
		} else {
			// 실패 시, 다시 등록 폼으로
			response.sendRedirect("add_product.jsp?error=true");
		}
	}

}