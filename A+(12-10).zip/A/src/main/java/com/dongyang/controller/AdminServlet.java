package com.dongyang.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.dongyang.dao.MemberDAO;
import com.dongyang.dao.ProductDAO;
import com.dongyang.dto.MemberDTO;

@WebServlet("/admin.do")
public class AdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // 1. 관리자 권한 확인 (보안)
        HttpSession session = request.getSession(false);
        MemberDTO loginUser = (session != null) ? (MemberDTO) session.getAttribute("memberId") : null;

        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            response.sendRedirect("main.jsp"); // 권한 없으면 내쫓기
            return;
        }

        // 2. 요청 파라미터 받기
        String action = request.getParameter("action");

        // 3. DAO 준비
        MemberDAO mdao = new MemberDAO();
        ProductDAO pdao = new ProductDAO();

        try {
            // [기존] 회원 1명 삭제
            if ("deleteMember".equals(action)) {
                String memberId = request.getParameter("memberId");
                if (memberId != null) {
                    mdao.deleteMember(memberId);
                }
            } 
            // [기존] 상품 1개 삭제
            else if ("deleteProduct".equals(action)) {
                int productId = Integer.parseInt(request.getParameter("productId"));
                pdao.deleteProduct(productId);
            }
            
            // ⭐️ [추가] 회원 선택 삭제 (여러 명)
            else if ("deleteBulkMembers".equals(action)) {
                // 체크박스로 선택된 ID들은 배열로 들어옵니다.
                String[] memberIds = request.getParameterValues("ids");
                
                if (memberIds != null) {
                    for (String id : memberIds) {
                        // (선택사항) 운영진(admin) 계정은 실수로 삭제되지 않도록 방어 로직을 넣을 수도 있습니다.
                        // 현재는 그냥 삭제합니다.
                        mdao.deleteMember(id);
                    }
                }
            }
            
            // ⭐️ [추가] 상품 선택 삭제 (여러 개)
            else if ("deleteBulkProducts".equals(action)) {
                String[] productIds = request.getParameterValues("ids");
                
                if (productIds != null) {
                    for (String idStr : productIds) {
                        try {
                            int id = Integer.parseInt(idStr); // 문자를 숫자로 변환
                            pdao.deleteProduct(id);
                        } catch (NumberFormatException e) {
                            e.printStackTrace(); // 숫자가 아닌 값이 들어오면 무시
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("관리자 작업 중 에러 발생: " + e.getMessage());
        }

     // 4. 작업 완료 후 원래 보던 탭으로 이동
        String tab = request.getParameter("tab"); // JSP에서 보낸 탭 정보 받기

        if (tab != null && !tab.isEmpty()) {
            response.sendRedirect("admin.jsp?tab=" + tab);
        }
    }
}